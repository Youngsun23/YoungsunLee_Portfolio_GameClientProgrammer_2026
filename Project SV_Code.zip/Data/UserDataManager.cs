using System.Collections.Generic;

public partial class UserDataManager : SingletonBase<UserDataManager>
{
    private UserDataDTO UserData = new UserDataDTO();

    public void UpdateUserDataBedTime(float time)
    {
        UserData.bedTime = time;
    }

    public void UpdateUserDataDay(int day)
    {
        UserData.day = day + 1;
    }

    public void UpdateUserDataResource(List<CharacterResourceData> resources)
    {
        UserData.resource = resources;
    }

    public void UpdateUserDataInventory(List<ItemSlot> inven)
    {
        UserData.inventory = inven;
    }

    public void UpdateUserDataExp(int value)
    {
        UserData.exp += value;

        if (UserData.isMaxLevel)
        {
        }
    }

    public void UpdateUserDataLevel()
    {
        UserData.level++;
    }

    public void UpdateUserDataEquipment(EquipItem item, bool equip)
    {
        if (equip)
            UserData.equippedItems.Add(item);
        else
            UserData.equippedItems.Remove(item);
    }

    public void UpdateUserDataEquipmentAtOnce(ItemContainer equipBox)
    {
        UserData.equippedItems.Clear();

        foreach (ItemSlot slot in equipBox.ItemSlots)
        {
            if (slot.Item != null)
            {
                UserData.equippedItems.Add(slot.Item as EquipItem);
            }
        }
    }

    public void UpdateUserDataCropTiles(List<CropTile> _cropTiles)
    {
        UserData.cropTiles = _cropTiles;
    }

    public void UpdateUserDataPlacedItems(List<PlacedItem> _placedItems)
    {
        UserData.placedItems = _placedItems;
    }

    public List<CharacterResourceData> GetUserDataResource() => UserData.resource;
    public int GetUserDataDay() => UserData.day;
    public float GetUserDataBedTime() => UserData.bedTime;
    public List<ItemSlot> GetUserDataInventory() => UserData.inventory;
    public int GetUserDataLevel() => UserData.level;
    public int GetUserDataEXP() => UserData.exp;
    public int GetUserDataSkillPoint() => UserData.skillPoint;
    public bool GetUserDataIsMaxLevel() => UserData.isMaxLevel;
    public List<EquipItem> GetUserDataEquippedItems() => UserData.equippedItems;
    public List<CropTile> GetUserDataCropTiles() => UserData.cropTiles;
    public List<PlacedItem> GetUserDataPlacedItems() => UserData.placedItems;
}

[System.Serializable]
public class UserDataDTO
{
    public List<CharacterResourceData> resource = new List<CharacterResourceData>();
    public int day;
    public float bedTime;
    public List<ItemSlot> inventory = null;
    public int level;
    public int exp;
    public int skillPoint;
    public bool isMaxLevel;

    public List<EquipItem> equippedItems = new List<EquipItem>();

    public List<CropTile> cropTiles = new List<CropTile>();
    public List<PlacedItem> placedItems = new List<PlacedItem>();

    public UserDataDTO()
    {
        day = 1;
        bedTime = 1860f;
        level = 1;
        exp = 0;
        skillPoint = 0;
        isMaxLevel = false;

        resource.Clear();
        equippedItems.Clear();
        cropTiles.Clear();
        placedItems.Clear();
    }
}


