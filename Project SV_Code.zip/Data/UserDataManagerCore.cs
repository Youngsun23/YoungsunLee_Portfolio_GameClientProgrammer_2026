using System.IO;
using UnityEngine;

public partial class UserDataManager : SingletonBase<UserDataManager>
{
    public void Save()
    {
        string serializeUserData = JsonUtility.ToJson(UserData, true);

        FileUtility.WriteFileFromString("Assets/Resources/UserData.txt", serializeUserData);
    }

    public void Load()
    {
        if (FileUtility.ReadFileData("Assets/Resources/UserData.txt", out string loadedUserData))
        {
            UserData = JsonUtility.FromJson<UserDataDTO>(loadedUserData);
        }
        else
        {
            UserData = new UserDataDTO();
        }
    }

    public void Delete()
    {
        string filePath = "Assets/Resources/UserData.txt";

        if (File.Exists(filePath))
        {
            File.Delete(filePath);
        }
        else
        {
            Debug.Log("삭제할 파일을 찾지 못했습니다.");
        }
    }

    public void BuildSave()
    {
        string filePath = Path.Combine(Application.persistentDataPath, "UserData.txt");
        string serializeUserData = JsonUtility.ToJson(UserData, true);
        FileUtility.WriteFileFromString(filePath, serializeUserData);
    }

    public void BuildLoad()
    {
        string filePath = Path.Combine(Application.persistentDataPath, "UserData.txt");
        if (FileUtility.ReadFileData(filePath, out string loadedUserData))
        {
            UserData = JsonUtility.FromJson<UserDataDTO>(loadedUserData);
            PlayerCharacter.Singleton.InitializeCharacterAttribute();
        }
    }

    public void BuildDelete()
    {
        string filePath = Path.Combine(Application.persistentDataPath, "UserData.txt");

        if (File.Exists(filePath))
        {
            File.Delete(filePath);
        }
    }
}

