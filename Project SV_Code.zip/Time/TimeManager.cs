using System;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.Rendering.Universal;

public class TimeManager : SingletonBase<TimeManager>
{
    // 7:00AM ~ 1:00AM
    // 1틱 = 게임 10m
    const float secondsInDay = 1500f;
    const float tickLength = 10f;
    private float startTime = 420f;

    [SerializeField] private Color dayLightColor = Color.white;
    [SerializeField] private Color nightLightColor;
    [SerializeField] private AnimationCurve lightColorCurve;
    [SerializeField] private Light2D globalLight;

    [SerializeField] private float timeScale = 1f;
    public float currentTime => time;
    private float time;
    public int Hours => hours;
    public int Minutes => minutes;
    private int hours;
    private int minutes;
    public int Day => days;
    private int days;

    private int prevHour = -1;
    private int prevMinute = -1;
    public event Action<int> OnDateChanged;

    private List<TimeAgent> agents;
    [SerializeField] private int tickPhase = 0;

    protected override void Awake()
    {
        base.Awake();
        agents = new List<TimeAgent>();
    }

    private void Start()
    {

    }

    public void Subscribe(TimeAgent agent)
    {
        agents.Add(agent);
    }

    public void UnSubscribe(TimeAgent agent)
    {
        agents.Remove(agent);
    }

    private void Update()
    {
        time += Time.deltaTime * timeScale;

        TimeCalculation();
        DayLight();

        if (time > secondsInDay)
        {
            StartNextDay();
        }

        TimeTick();
    }

    private void TimeTick()
    {
        int currentPhase = (int)(time / tickLength);

        if (tickPhase != currentPhase)
        {
            tickPhase = currentPhase;
            for (int i = 0; i < agents.Count; i++)
            {
                agents[i]?.InvokeTick();
            }
        }
    }

    private void DayLight()
    {
        float v = lightColorCurve.Evaluate(Hours);
        Color c = Color.Lerp(dayLightColor, nightLightColor, v);
        globalLight.color = c;
    }

    private void TimeCalculation()
    {
        hours = (int)(time / (tickLength * 6f));
        minutes = (int)((time % (tickLength * 6f) / tickLength) * 10f);

        if (hours != prevHour || minutes != prevMinute)
        {
            prevHour = hours;
            prevMinute = minutes;
        }
    }

    public void StartNextDay()
    {
        int skippedTicks = TimeSkipCalculation(time);
        SkipTickAgents(skippedTicks);
        SkipTickTime(skippedTicks);

        time = startTime;
        tickPhase = 0;
        days++;
        DateChangeEvent();

        if (days >= 28)
            StartNextSeason();
    }

    public void StartNewDay()
    {
        int skippedTicks = TimeSkipCalculation(UserDataManager.Singleton.GetUserDataBedTime());
        SkipTickAgents(skippedTicks);

        time = startTime;
        tickPhase = 0;
        days = UserDataManager.Singleton.GetUserDataDay();
        DateChangeEvent();

        if (days >= 28)
            StartNextSeason();
    }

    public void DateChangeEvent()
    {
        OnDateChanged?.Invoke(days);
    }

    private void StartNextSeason()
    {
        days = 1;
    }

    private int TimeSkipCalculation(float bedTime)
    {
        float skippedSeconds = 360 + (1500f - bedTime);
        int skippedTicks = (int)(skippedSeconds / tickLength);
        return skippedTicks;
    }

    public void SkipTickAgents(int tick)
    {
        for (int i = 0; i < tick; i++)
        {
            for (int j = 0; j < agents.Count; j++)
            {
                agents[j]?.InvokeTick();
            }
        }
    }

    public void SkipTickTime(int tick)
    {
        time += tickLength * tick;
    }
}
