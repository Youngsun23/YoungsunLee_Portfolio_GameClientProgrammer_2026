using System.Collections;
using UnityEngine;

public class GameManager : SingletonBase<GameManager>
{
    public GameObject Player => player;
    [SerializeField] private GameObject player;
    public ItemContainer Inventory => inventory;
    [SerializeField] private ItemContainer origin_inventory;
    public ItemDragDropController ItemDragDropController { get; private set; }
    [SerializeField] private ItemContainer inventory;
    public DialogueManager DialogueManager => dialogueManager;
    private DialogueManager dialogueManager;
    public PlaceableItemHighlight PlaceableItemHighlight => placeableHighlight;
    [SerializeField] private PlaceableItemHighlight placeableHighlight;
    public TradeManager TradeManager => tradeManager;
    [SerializeField] private TradeManager tradeManager;

    private bool initialized = false;

    protected override void Awake()
    {
        base.Awake();

        StartCoroutine(DelayedInitialize());
    }

    private void Start()
    {

    }

    private IEnumerator DelayedInitialize()
    {
        yield return null;

        if (!initialized)
        {
#if UNITY_EDITOR
            UserDataManager.Singleton.Load();
#else
        UserDataManager.Singleton.BuildLoad();
#endif
            
            if (UserDataManager.Singleton.GetUserDataInventory() != null)
            {
                origin_inventory = new ItemContainer();
                origin_inventory.Init();
                origin_inventory.SetItemList(UserDataManager.Singleton.GetUserDataInventory());
            }
            inventory = Instantiate(origin_inventory);


            PlayerCharacter.Singleton.InitializeCharacterAttribute();

            UIManager.Show<ToolBarUI>(UIType.ToolBar);
            UIManager.Show<DragDropUI>(UIType.DragDrop);
            ItemDragDropController = UIManager.Singleton.GetUI<DragDropUI>(UIType.DragDrop).GetComponent<ItemDragDropController>();
            dialogueManager = UIManager.Singleton.GetUI<DialogueUI>(UIType.Dialogue).GetComponent<DialogueManager>();
            UIManager.Hide<DialogueUI>(UIType.Dialogue);
            UIManager.Show<HUDUI>(UIType.HUD);

            initialized = true;
        }
    }

    public void TempGameQuit()
    {
        Application.Quit();
    }
}
