using UnityEngine;

public interface IActor
{
    GameObject GetActor();
}

public interface IDamage
{
    void TakeDamage(IActor actor, float damage);
}
