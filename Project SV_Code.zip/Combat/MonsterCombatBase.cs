using UnityEngine;
public enum MonsterAIState
{
    PeaceState,
    CombatState,
}

public class MonsterCombatBase : MonoBehaviour, IActor, IDamage
{
    [field: SerializeField] public MonsterAIState AIState { get; protected set; }
    [field: SerializeField] public float MaxHP { get; protected set; }
    [field: SerializeField] public float MaxStamina { get; protected set; }
    [field: SerializeField] public float MoveSpeed { get; protected set; }
    [field: SerializeField] public float PatrolRange { get; protected set; }
    [field: SerializeField] public float DetectRadius { get; protected set; }
    [field: SerializeField] public float AttackPossibleRadius { get; protected set; }
    [field: SerializeField] public float AttackRadius { get; protected set; }
    [field: SerializeField] public float AttackDamage { get; protected set; }
    [field: SerializeField] public float AttackCoolTime { get; protected set; }

    [SerializeField] private float currentHP;
    [SerializeField] private float currentStamina;

    [SerializeField] private MonsterGameData monsterStatData;
    [SerializeField] private MonsterOwnedSensor sensor;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Animator animator;

    private PlayerCharacter targetPlayer;
    private bool hasPatrolTargetPos = false;
    private Vector3 targetPatrolPos;
    private bool attackAvailable = true;
    private bool justAttacked = false;
    private float attackCoolTimer;
    private bool isDead = false;
    private float stunTimer = 0f;
    private Coroutine hitCoroutine;

    private void Awake()
    {
        MaxHP = monsterStatData.MaxHP;
        MaxStamina = monsterStatData.MaxStamina;
        MoveSpeed = monsterStatData.MoveSpeed;
        PatrolRange = monsterStatData.PatrolRange;
        DetectRadius = monsterStatData.DetectRadius;
        AttackPossibleRadius = monsterStatData.AttackPossibleRadius;
        AttackRadius = monsterStatData.AttackRadius;
        AttackDamage = monsterStatData.AttackDamage;
        AttackCoolTime = monsterStatData.AttackCoolTime;
        sensor.SetSensorDetectRadius(monsterStatData.DetectRadius);
    }

    private void Start()
    {
        sensor.OnDetectedTarget += OnDetectedPlayer;
        sensor.OnLostTarget += OnLostPlayer;
        currentHP = MaxHP;
    }

    private void FixedUpdate()
    {
        if (isDead)
            return;

        switch (AIState)
        {
            case MonsterAIState.CombatState:
                {
                    if (justAttacked)
                    {
                        attackCoolTimer += Time.deltaTime;
                        if (attackCoolTimer >= AttackCoolTime)
                        {
                            justAttacked = false;
                            attackAvailable = true;
                        }
                    }
                    else if (Vector2.Distance(transform.position, targetPlayer.transform.position) <= AttackPossibleRadius)
                    {
                        Attack();
                    }
                    else
                    {
                        Chase();
                    }
                }
                break;
            case MonsterAIState.PeaceState:
                {
                    Patrol();
                }
                break;
        }
    }

    public void Patrol()
    {
        if (!hasPatrolTargetPos)
        {
            targetPatrolPos = GetRandomPosition();
            hasPatrolTargetPos = true;
        }
        else if (Vector2.Distance(transform.position, targetPatrolPos) <= 0.1f)
            hasPatrolTargetPos = false;

        Vector3 targetPos = Vector3.MoveTowards(transform.position, targetPatrolPos, MoveSpeed * Time.deltaTime);
        rb.MovePosition(targetPos);
    }

    public void Chase()
    {
        Vector3 targetPos = Vector3.MoveTowards(transform.position, targetPlayer.transform.position, MoveSpeed * 2f * Time.deltaTime);
        rb.MovePosition(targetPos);
    }

    public void Attack()
    {
        if (attackAvailable)
            animator.SetTrigger("Attack");

        attackAvailable = false;
        Vector3 targetPos = Vector3.MoveTowards(transform.position, targetPlayer.transform.position, AttackRadius * 3f * Time.deltaTime);
        rb.MovePosition(targetPos);
    }

    public void ExecuteAttack()
    {
        justAttacked = true;
        attackCoolTimer = 0f;
    }

    private Vector3 GetRandomPosition()
    {
        Vector3 randomOffset = Random.insideUnitCircle * PatrolRange;
        return transform.position + randomOffset;
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (isDead)
            return;

        if (other.collider.CompareTag("ColliderWall"))
        {
            hasPatrolTargetPos = false;
            return;
        }

        if (other.collider.TryGetComponent(out PlayerCharacter character))
        {
            character.TakeDamage(this, AttackDamage);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {

    }

    public void OnDetectedPlayer(PlayerCharacter player)
    {
        AIState = MonsterAIState.CombatState;
        targetPlayer = player;
    }

    public void OnLostPlayer(PlayerCharacter player)
    {
        AIState = MonsterAIState.PeaceState;
        targetPlayer = null;
    }

    public GameObject GetActor()
    {
        return this.gameObject;
    }

    public void TakeDamage(IActor actor, float damage)
    {
        if (isDead)
            return;

        KnockBack(actor);

        OnScreenMessageManager.Singleton.ShowMessageOnScreen(transform.position, damage.ToString());

        currentHP -= damage;

        if (currentHP <= 0f)
        {
            Die();
        }
    }

    private void KnockBack(IActor actor)
    {
        Vector2 direction = transform.position - actor.GetActor().transform.position;
        direction.Normalize();

        rb.AddForce(direction * MoveSpeed * 2f, ForceMode2D.Impulse);
    }

    private void Die()
    {
        isDead = true;

        animator.SetTrigger("Die");

        rb.bodyType = RigidbodyType2D.Static;

        Destroy(this.gameObject, 2f);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, DetectRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, AttackRadius);
    }
}