using UnityEngine;
using UnityEngine.Tilemaps;

public class TileMapCropsManager : MonoBehaviour
{
    public PlantedCropsContainer Container => PlantedCropsManager.Singleton.Container;

    [SerializeField] private TileBase plowed;
    [SerializeField] private Tilemap cropTargetTileMap;
    [SerializeField] private Tilemap plowTargetTileMap;
    [SerializeField] private Tilemap plantTargetTileMap;
    [SerializeField] private GameObject cropSpritePrefab;
    private float spread = 2f;

    private void Awake()
    {
        cropTargetTileMap = GetComponent<Tilemap>();
        CropManager.Singleton.SetCropsManager(this);
    }


    private void Start()
    {

    }

    private void OnDestroy()
    {
        for (int i = 0; i < Container.Crops.Count; i++)
        {
            Container.Crops[i].SetRenderer(null);
        }

        CropManager.Singleton.SetCropsManager(null);
    }

    public void Initialize()
    {
        Debug.Log("TileMapCropsManager - Initialize()");

        Container.ClearCropTileList();
        LoadCropTilesData();
        VisualizeTiles();
    }

    public void InitilizeScene()
    {
        Debug.Log("TileMapCropsManager - InitializeScene()");

        VisualizeTiles();
    }

    public void SaveCropTilesData()
    {
        UserDataManager.Singleton.UpdateUserDataCropTiles(Container.Crops);
    }

    public void LoadCropTilesData()
    {
        Container.SetCropTileList(UserDataManager.Singleton.GetUserDataCropTiles());
    }

    public void SaveRuntimeCropTilesData()
    {
        Debug.Log("TileMapCropsManager - SaveRuntimeCropTilesData()");
    }

    public void LoadRuntimeCropTilesData()
    {
        Debug.Log("TileMapCropsManager - LoadRuntimeCropTilesData()");
    }

    public bool IsPlantable(Vector3Int pos)
    {
        if (Container.GetCropTile(pos) == null || Container.GetCropTile(pos).CropData != null)
            return false;
        else
            return true;
    }

    public void Plow(Vector3Int pos)
    {
        if (Container.GetCropTile(pos) != null)
            return;

        CreatePlowedTile(pos);
    }

    public void Plant(Vector3Int pos, CropData seed)
    {
        CropTile tile = Container.GetCropTile(pos);
        tile.SetCrop(seed);

        VisualizeTile(tile);
    }

    public void VisualizeTiles()
    {
        foreach (var tile in Container.Crops)
        {
            VisualizeTile(tile);
        }
    }

    public void VisualizeTile(CropTile cropTile)
    {
        cropTargetTileMap.SetTile(cropTile.Position, plowed);

        if (cropTile.CropData != null)
        {
            GameObject cropSprite = Instantiate(cropSpritePrefab);
            cropSprite.transform.position = cropTargetTileMap.GetCellCenterWorld(cropTile.Position);

            SpriteRenderer sr = cropSprite.GetComponent<SpriteRenderer>();
            sr.sortingLayerName = "WalkInfront";
            sr.sortingOrder = 2;
            cropTile.SetRenderer(sr);
            cropTile.SetSprite(cropTile.CropData.GetGrowthSprite(cropTile.CurrentGrowthStage));
        }
    }

    public void PickupCrop(Vector3Int pos)
    {
        if (Container.GetCropTile(pos) == null) return;
        if (!Container.GetCropTile(pos).IsMature) return;

        Item yield = Container.GetCropTile(pos).CropData.GetYield();
        int yieldCount = Container.GetCropTile(pos).CropData.GetYieldCount();

        Vector3 worldPos = cropTargetTileMap.GetCellCenterWorld(pos);
        worldPos.x += spread * Random.value * 2 - spread;
        worldPos.y += spread * Random.value * 2 - spread;
        ItemSpawnManager.Singleton.SpawnItem((Vector3)worldPos, yield, yieldCount);
        CreateHarvestedTile(pos);
    }

    private void CreatePlowedTile(Vector3Int pos)
    {
        if (cropTargetTileMap == null)
            return;

        CropTile crop = new CropTile(null, pos);
        Container.Crops.Add(crop);

        cropTargetTileMap.SetTile(pos, plowed);
    }

    private void CreateHarvestedTile(Vector3Int pos)
    {
        Destroy(Container.GetCropTile(pos).Renderer.gameObject);
        Container.GetCropTile(pos).ResetCropTile();
    }

    public void SetPlowTargetTileMap(Tilemap target)
    {
        plowTargetTileMap = target;
    }

    public void SetPlantTargetTileMap(Tilemap target)
    {
        plantTargetTileMap = target;
    }
}
