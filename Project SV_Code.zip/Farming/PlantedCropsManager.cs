using UnityEngine;

public class PlantedCropsManager : SingletonBase<PlantedCropsManager>
{
    public PlantedCropsContainer Container => container;
    [SerializeField] private PlantedCropsContainer container;
}
