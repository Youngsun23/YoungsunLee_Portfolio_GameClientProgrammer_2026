using System.Collections.Generic;
using UnityEngine;

public class BuyPanel : ItemPanel
{
    protected override ItemContainer Inventory => tradeInventory;
    private ItemContainer tradeInventory;
    [SerializeField] private GameObject buyButtonPrefab;
    private List<GameObject> instantaitedButtons = new List<GameObject>();

    protected override void Start()
    {
        base.Start();
    }

    private void OnEnable()
    {
        ClearPanelUI();
        SetInventory(GameManager.Singleton.TradeManager.TradeInventory);
        SetPanelUI();
    }

    private void OnDisable()
    {

    }

    private void SetInventory(ItemContainer inventory)
    {
        tradeInventory = inventory;
    }

    private void SetPanelUI()
    {
        int slotCount = tradeInventory.ItemSlots.Count;

        for (int i = 0; i < slotCount; i++)
        {
            GameObject buyButton = Instantiate(buyButtonPrefab);
            buyButton.transform.SetParent(gameObject.transform, false);
            buttons.Add(buyButton.GetComponent<BuyButton>());
            instantaitedButtons.Add(buyButton);
        }

        Initialize();
    }

    private void ClearPanelUI()
    {
        foreach (GameObject button in instantaitedButtons)
        {
            Destroy(button);
        }
        buttons.Clear();
    }

    public override void OnClick(int id, bool isLeft)
    {
        GameManager.Singleton.TradeManager.OnClickBuy(Inventory.ItemSlots[id]);

        Show();
    }
}
