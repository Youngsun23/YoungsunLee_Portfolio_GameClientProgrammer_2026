using UnityEngine;

public class ItemConvertorInteraction : MonoBehaviour, IInteractable
{
    [SerializeField] private Item convertableItem;
    [SerializeField] private Item convertedItem;
    [SerializeField] private int convertedItemCount = 1;
    private ItemConvertorData data;
    private Animator animator;
    private ToolBarController toolBarController;

    private void Awake()
    {
        if (data == null)
        {
            data = new ItemConvertorData();
        }
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        LoadConvertorData();
        animator.SetBool("Working", data.IsConverting);

        toolBarController = UIManager.Singleton.GetUI<ToolBarUI>(UIType.ToolBar).GetComponent<ToolBarController>();
    }

    private void OnDestroy()
    {
        SaveConvertorData();
    }

    private void Update()
    {
        if (data == null) return;

        if (data.IsConvertingOver)
            animator.SetBool("Working", false);
    }

    public void Interact(PlayerCharacterController character)
    {
        if (data.ItemSlot.Item == null)
        {
            if (GameManager.Singleton.ItemDragDropController.ConvertableCheck(convertableItem))
            {
                StartItemConverting(GameManager.Singleton.ItemDragDropController.DragDropSlot);
                return;
            }

            if (toolBarController?.GetCurrentHoldingItem() == convertableItem)
            {
                StartItemConverting(toolBarController.GetCurrentItemSlot());
            }
        }
        else
        {
            if (data.IsConvertingOver)
            {
                GameManager.Singleton.Inventory.AddItem(convertedItem, convertedItemCount);
                data.ResetData();
            }
        }
    }


    private void StartItemConverting(ItemSlot toProcess)
    {
        animator.SetBool("Working", true);

        data.ItemSlot.Copy(toProcess);
        data.ItemSlot.SetCount(1);
        data.SetIsConverting(true);
        SaveConvertorData();

        if (toProcess.Item.Stackable)
        {
            toProcess.ChangeCount(-1);
            if (toProcess.Count < 0)
                toProcess.Clear();
        }
        else
        {
            toProcess.Clear();
        }

        GameManager.Singleton.Inventory.onChange?.Invoke();
    }

    public void SaveConvertorData()
    {
        PlacedItem item = PlaceableObjectsManager.Singleton.Container.PlacedItems.Find(x => x.Transform == this.gameObject.GetComponent<Transform>());
        item.SetItemConvertorData(data);
    }

    public void LoadConvertorData()
    {
        PlacedItem item = PlaceableObjectsManager.Singleton.Container.PlacedItems.Find(x => x.Transform == this.gameObject.GetComponent<Transform>());
        if (item?.ConvertorData != null)
            this.data = item.ConvertorData;
    }
}
