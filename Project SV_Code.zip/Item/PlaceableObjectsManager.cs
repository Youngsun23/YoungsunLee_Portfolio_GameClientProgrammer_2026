using UnityEngine;
using UnityEngine.Tilemaps;

public class PlaceableObjectsManager : SingletonBase<PlaceableObjectsManager>
{
    public PlacedItemsContainer Container => container;
    [SerializeField] private PlacedItemsContainer container;
    [SerializeField] private Tilemap targetTileMap;
    public bool isInitialized { get; private set; } = false;

    public void Initialize()
    {
        Debug.Log("PlaceableObjectsManager - Initialize()");

        container.ClearPlacedItemsList();
        LoadPlacedItemsData();
        VisualizePlacedObjects();
    }

    public void InitilizeScene()
    {
        Debug.Log("PlaceableObjectsManager - InitializeScene()");

        LoadRuntimePlacedItemsData();
        VisualizePlacedObjects();
    }

    public void SetInitialized(bool tf)
    {
        isInitialized = tf;
    }

    public void SavePlacedItemsData()
    {
        UserDataManager.Singleton.UpdateUserDataPlacedItems(container.PlacedItems);
    }

    public void LoadPlacedItemsData()
    {
        container.SetPlacedItemsList(UserDataManager.Singleton.GetUserDataPlacedItems());
    }

    public void SaveRuntimePlacedItemsData()
    {
        Debug.Log("PlaceableObjectsManager - SaveRuntimePlacedItemsData()");
    }

    public void LoadRuntimePlacedItemsData()
    {
        Debug.Log("PlaceableObjectsManager - LoadRuntimePlacedItemsData()");
    }

    public void VisualizePlacedObjects()
    {
        for (int i = 0; i < container.PlacedItems.Count; i++)
        {
            VisualizePlacedObject(container.PlacedItems[i]);
        }
    }

    private void VisualizePlacedObject(PlacedItem placedItem)
    {
        if (targetTileMap == null)
        {
            Debug.Log("targetTileMap == null");
            return;
        }

        GameObject go = Instantiate(placedItem.Item.ItemPrefab);
        Vector3 position = targetTileMap.CellToWorld(placedItem.Position) + targetTileMap.cellSize / 2;
        go.transform.position = position;
        placedItem.SetTransform(go.transform);
    }

    public bool Place(Item item, Vector3Int pos)
    {
        if (container.PlacedItems.Find(x => x.Position == pos) != null) return false;

        PlacedItem placedItem = new PlacedItem(item, pos);
        VisualizePlacedObject(placedItem);
        container.PlacedItems.Add(placedItem);
        return true;
    }

    public void Pickup(Vector3Int pos)
    {
        PlacedItem placedItem = container.PlacedItems.Find(x => x.Position == pos);
        if (placedItem == null) return;

        if (placedItem.ConvertorData?.ItemSlot?.Item != null)
            return;
        for (int i = 0; i < placedItem.StorageData?.ItemSlots?.Count; i++)
        {
            if (placedItem.StorageData.ItemSlots[i].Item != null)
                return;
        }

        ItemSpawnManager.Singleton.SpawnItem(targetTileMap.CellToWorld(pos), placedItem.Item, 1);
        Destroy(placedItem.Transform.gameObject);
        container.PlacedItems.Remove(placedItem);
    }

    public void SetTargetTileMap(Tilemap _targetTileMap)
    {
        targetTileMap = _targetTileMap;
    }
}
