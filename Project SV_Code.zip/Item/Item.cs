using UnityEngine;

public enum ItemType
{
    None,

    Wood,
    Stone,
    Thread,
    Carrot,
    Stick,
    FishingPole,

    Else
}

public enum TriggerType
{
    None,

    Axe,
    Pickaxe,
    Hoe,
    Sword,
    Seed,
    Pickup,

    Else
}

[CreateAssetMenu(menuName = "Data/Item/Item")]
public class Item : GameDataBase
{
    public string Name => itemName;
    public string Info => itemInfo;
    public bool Stackable => stackable;
    public Sprite Icon => icon;
    public int BuyPrice => buyPrice;
    public int SellPrice => sellPrice;
    public ToolAction OnToolAction => onToolAction;
    public ToolAction OnToolActionTileMap => onToolActionTileMap;
    public CropData CropData => crop;
    public TriggerType TriggerType => triggerType;
    public ItemType ItemType => itemType;
    public bool Placeable => placeable;
    public GameObject ItemPrefab => itemPrefab;

    [SerializeField] private string itemName;
    [SerializeField] private string itemInfo;
    [SerializeField] private bool stackable;
    [SerializeField] private Sprite icon;
    [SerializeField] private int buyPrice;
    [SerializeField] private int sellPrice;
    [SerializeField] private ToolAction onToolAction;
    [SerializeField] private ToolAction onToolActionTileMap;
    [SerializeField] private CropData crop;
    [SerializeField] private TriggerType triggerType;
    [SerializeField] private ItemType itemType;
    [SerializeField] private bool placeable;
    [SerializeField] private GameObject itemPrefab;
}