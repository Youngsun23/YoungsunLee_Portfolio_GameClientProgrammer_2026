using UnityEngine;

public class ToolAction : ScriptableObject
{
    public int StaminaCost => staminaCost;
    [SerializeField] private int staminaCost;

    public virtual bool OnApply(Vector2 pos, Item usedItem)
    {
        Debug.LogWarning("OnApply() Override Needed");
        return true;
    }

    public virtual bool OnApplyTileMap(Vector3Int pos, TileData tile, Item usedItem)
    {
        Debug.LogWarning("OnApplyTileMap() Override Needed");
        return true;
    }

    public virtual void OnItemUsed(Item usedItem, ItemContainer inventory)
    {

    }

    public virtual void OnComplete()
    {
        PlayerCharacter.Singleton.UseStamina(staminaCost);
    }
}

