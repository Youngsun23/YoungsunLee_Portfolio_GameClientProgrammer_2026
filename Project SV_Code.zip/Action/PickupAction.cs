using UnityEngine;

[CreateAssetMenu(menuName = "Data/Tool Action/Pickup")]
public class PickupAction : ToolAction
{
    public override bool OnApplyTileMap(Vector3Int pos, TileData tile, Item usedItem)
    {
        CropManager.Singleton.PickupCrop(pos);

        PlaceableObjectsManager.Singleton.Pickup(pos);

        return true;
    }
}
