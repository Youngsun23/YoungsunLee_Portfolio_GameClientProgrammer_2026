using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class HitNode : ToolHit
{
    [SerializeField] private int hitMaxHP;
    [SerializeField] private int hitCurHP;
    [SerializeField] private Item item;
    [SerializeField] private int dropCount = 3;
    [SerializeField] private float spread = 1f;
    [SerializeField] private HitNodeType nodeType;
    [SerializeField] private float probability = 0.5f;

    private void Awake()
    {
        hitCurHP = hitMaxHP;
    }

    public override void Hit()
    {
        if (hitCurHP <= 0)
            return;

        Vector2 hitDir = PlayerCharacter.Singleton.transform.position - transform.position;
        transform.position += (Vector3)(hitDir.normalized * 0.05f);

        hitCurHP--;
        if (hitCurHP == 0)
            StartCoroutine(DestroyHitNode(hitDir));
        else
            StartCoroutine(ShakeHitNode(hitDir));

        if (Random.value < probability)
        {

        }

        // SpawnDropItem();
        // Destroy(gameObject);
    }

    public override bool IsHittable(List<HitNodeType> hitNodeType)
    {
        return hitNodeType.Contains(nodeType);
    }

    private void SpawnDropItem()
    {
        for (int i = dropCount; i > 0; i--)
        {
            Vector3 position = transform.position;
            position.x += spread * Random.value * 2 - spread;
            position.y += spread * Random.value * 2 - spread;

            ItemSpawnManager.SpawnItem(position, item);
        }
    }

    IEnumerator ShakeHitNode(Vector2 hitDir)
    {
        float duration = 0.3f;
        float elapsed = 0f;
        float maxAngle = 8f * Mathf.Sign(hitDir.x);

        while (elapsed < duration)
        {
            float t = elapsed / duration;
            float angle = Mathf.Sin(t * Mathf.PI) * maxAngle;
            transform.rotation = Quaternion.Euler(0, 0, angle);

            elapsed += Time.deltaTime;
            yield return null;
        }

        transform.rotation = Quaternion.identity;
    }

    IEnumerator DestroyHitNode(Vector2 hitDir)
    {
        float duration = 0.8f;
        float elapsed = 0f;

        float startAngle = 0f;
        float endAngle = 90f * Mathf.Sign(hitDir.x);

        Vector3 startPos = transform.position;
        Vector3 endPos = startPos + (Vector3)(hitDir.normalized * 0.5f);

        while (elapsed < duration)
        {
            float t = elapsed / duration;

            float angle = Mathf.Lerp(startAngle, endAngle, t);
            transform.rotation = Quaternion.Euler(0, 0, angle);
            transform.position = Vector3.Lerp(startPos, endPos, t);

            elapsed += Time.deltaTime;
            yield return null;
        }

        SpawnDropItem();
        Destroy(gameObject);
    }

}
