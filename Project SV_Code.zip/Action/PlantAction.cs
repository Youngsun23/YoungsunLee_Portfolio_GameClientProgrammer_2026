using UnityEngine;

[CreateAssetMenu(menuName = "Data/Tool Action/Plant")]
public class PlantAction : ToolAction
{
    public override bool OnApplyTileMap(Vector3Int pos, TileData tile, Item usedItem)
    {
        if (CropManager.Singleton.IsPlantable(pos))
        {
            CropManager.Singleton.Plant(pos, usedItem.CropData);

            return true;
        }

        return false;
    }

    public override void OnItemUsed(Item usedItem, ItemContainer inventory)
    {
        inventory.RemoveItem(usedItem);
    }
}
