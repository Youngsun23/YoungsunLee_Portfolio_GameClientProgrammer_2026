using System;
using UnityEngine;

public enum ResourceTypes
{
    Coin,

    SpringOrb,
    SummerOrb,
    FallOrb,
    WinterOrb,

    EndField,
}

[Serializable]
public class CharacterResourceData
{
    public ResourceTypes Type => type;
    [SerializeField] private ResourceTypes type;
    public int Count => count;
    [SerializeField] private int count;

    public CharacterResourceData(ResourceTypes _type, int _count)
    {
        type = _type;
        count = _count;
    }
}

public class CharacterResource : MonoBehaviour
{
    public int Value { get; private set; }

    public System.Action<int> OnChanged;

    public void SetValue(int value)
    {
        Value = value;
    }
}
