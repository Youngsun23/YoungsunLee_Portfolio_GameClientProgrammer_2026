using UnityEngine;

public class CraftingPanel : ItemPanel
{
    [SerializeField] private RecipeContainer recipeContainer;

    public override void Show()
    {
        for (int i = 0; i < buttons.Count; i++)
        {
            buttons[i].Set(recipeContainer.Recipes[i].Output);
        }
    }
}
