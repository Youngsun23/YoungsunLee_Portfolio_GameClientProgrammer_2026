using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class CraftResultSlot : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] private Image icon;
    private Item resultItem;
    private CraftBoxPanel craftBoxPanel;

    private void Awake()
    {
        craftBoxPanel = transform.parent.GetComponent<CraftBoxPanel>();
        Clean();
    }

    public void Set(Item item)
    {
        resultItem = item;
        icon.gameObject.SetActive(true);
        icon.sprite = item.Icon;
    }

    public void Clean()
    {
        resultItem = null;
        icon.sprite = null;
        icon.gameObject.SetActive(false);
    }

    private void GetCraftedItem(Item craftedItem)
    {
        if (GameManager.Singleton.Inventory.AddItem(craftedItem))
        {
            CraftingSystemManager.Singleton.CraftBox.RemoveItemGrid();
            craftBoxPanel.Show();
        }
        else
        {
            Debug.Log("인벤토리가 가득 차 아이템을 획득할 수 없습니다.");
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (resultItem != null)
        {
            GetCraftedItem(resultItem);
        }
    }
}
