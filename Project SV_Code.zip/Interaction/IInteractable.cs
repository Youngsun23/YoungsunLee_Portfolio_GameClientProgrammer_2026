public interface IInteractable
{
    void Interact(PlayerCharacterController character);
}
