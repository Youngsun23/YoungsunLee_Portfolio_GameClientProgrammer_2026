using UnityEngine;

public class TradeInteraction : MonoBehaviour, IInteractable
{
    [SerializeField] private ItemContainer inventory;
    public void Interact(PlayerCharacterController character)
    {
        GameManager.Singleton.TradeManager.SetTradeInventory(inventory);
        UIManager.Show<TradeUI>(UIType.Trade);
    }
}
