using UnityEngine;

public class ChestInventoryInteraction : MonoBehaviour, IInteractable
{
    [SerializeField] private GameObject chestClosed;
    [SerializeField] private GameObject chestOpen;
    [SerializeField] private bool opened = false;
    public Animator animator;

    [SerializeField] private ItemContainer itemContainer;
    private ChestStorageData data;

    private void Awake()
    {
        if (data == null)
        {
            data = new ChestStorageData();
        }
    }

    private void Start()
    {
        if (itemContainer == null)
        {
            itemContainer = (ItemContainer)ScriptableObject.CreateInstance(typeof(ItemContainer));
            itemContainer.Init();
        }

        UIManager.Singleton.GetUI<ChestInventoryUI>(UIType.ChestInventory).onChestClosed += SaveStorageData;

        LoadStorageData();
    }

    private void OnDestroy()
    {
        UIManager.Singleton.GetUI<ChestInventoryUI>(UIType.ChestInventory).onChestClosed -= SaveStorageData;
    }

    private void SaveStorageData()
    {
        PlacedItem item = PlaceableObjectsManager.Singleton.Container.PlacedItems.Find(x => x.Transform == this.gameObject.GetComponent<Transform>());
        data.SetData(itemContainer.ItemSlots);
        item.SetChestStorageData(data);
    }

    private void LoadStorageData()
    {
        PlacedItem item = PlaceableObjectsManager.Singleton.Container.PlacedItems.Find(x => x.Transform == this.gameObject.GetComponent<Transform>());
        if (item?.StorageData != null)
        {
            this.data = item.StorageData;
            itemContainer.SetItemList(data.ItemSlots);
        }
    }

    public void Interact(PlayerCharacterController character)
    {
        UIManager.Singleton.GetUI<ChestInventoryUI>(UIType.ChestInventory).GetPanel().SetChestInventory(itemContainer); 

        UIManager.Show<ChestInventoryUI>(UIType.ChestInventory);
    }
}