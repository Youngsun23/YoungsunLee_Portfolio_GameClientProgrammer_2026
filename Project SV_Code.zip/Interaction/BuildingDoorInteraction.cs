using UnityEngine;

public class PlayerHouseDoorInteraction : MonoBehaviour, IInteractable
{
    [SerializeField] private string connectedRoomName;
    [SerializeField] private Vector2 destinationPosition;
    [SerializeField] private Collider2D confiner;

    public void Interact(PlayerCharacterController character)
    {
        PlayerCharacterController.Singleton.transform.position = destinationPosition;
        CameraSystem.Singleton.SetCameraConfiner(confiner);
    }
}
