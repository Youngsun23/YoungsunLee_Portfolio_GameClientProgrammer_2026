using System.Collections;
using UnityEngine;

public class SaveInteraction : MonoBehaviour, IInteractable
{
    public void Interact(PlayerCharacterController character)
    {
        StartCoroutine(BedSave());
    }

    IEnumerator BedSave()
    {
        PlayerCharacter.Singleton.DisableCharacterControl.DisableControl();

        var FadeUI = UIManager.Singleton.GetUI<FadeInOutUI>(UIType.FadeInOut);

        FadeUI.Show();
        FadeUI.FadeOut();
        yield return new WaitForSeconds(1);

        UserDataManager.Singleton.UpdateUserDataDay(TimeManager.Singleton.Day);
        UserDataManager.Singleton.UpdateUserDataBedTime(TimeManager.Singleton.currentTime);
        UserDataManager.Singleton.UpdateUserDataInventory(GameManager.Singleton.Inventory.ItemSlots);
        CropManager.Singleton.TileMapCropManger.SaveCropTilesData();
        PlaceableObjectsManager.Singleton.SavePlacedItemsData();
        PlayerCharacter.Singleton.CharacterResourceComponent.SaveCharacterResourceData();
        Debug.Log(UserDataManager.Singleton.GetUserDataResource()[0].Count);

#if UNITY_EDITOR
        UserDataManager.Singleton.Save();
#else
        UserDataManager.Singleton.BuildSave();
#endif

        PlayerCharacter.Singleton.WakeUp();
        TimeManager.Singleton.StartNextDay();

        yield return new WaitForSeconds(1.5f);
        FadeUI.FadeIn();
        yield return new WaitForSeconds(1);
        FadeUI.Hide();

        PlayerCharacter.Singleton.DisableCharacterControl.EnableControl();
    }
}
