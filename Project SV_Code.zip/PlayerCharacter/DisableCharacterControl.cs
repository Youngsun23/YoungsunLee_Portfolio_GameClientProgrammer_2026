using UnityEngine;

public class DisableCharacterControl : MonoBehaviour
{
    PlayerCharacterController characterController;
    PlayerCharacterToolController characterToolController;
    PlayerCharacterInteraction characterInteractionController;

    public bool IsDisabled => isDisabled;
    private bool isDisabled = false;

    private void Awake()
    {
        characterController = GetComponent<PlayerCharacterController>();
        characterToolController = GetComponent<PlayerCharacterToolController>();
        characterInteractionController = GetComponent<PlayerCharacterInteraction>();
    }

    public void DisableControl()
    {
        isDisabled = true;
        characterController.enabled = false;
        characterToolController.enabled = false;
        characterInteractionController.enabled = false;
    }

    public void EnableControl()
    {
        isDisabled = false;
        characterController.enabled = true;
        characterToolController.enabled = true;
        characterInteractionController.enabled = true;
    }
}
