using UnityEngine;

public class PlayerCharacterController : SingletonBase<PlayerCharacterController>
{
    [SerializeField] private Animator animator;
    [SerializeField] private PlayerCharacterToolController toolController;
    [SerializeField] private PlayerCharacterInteraction interaction;
    private Rigidbody2D rigidBody;
    private SpriteRenderer spriteRenderer;

    public Vector2 lastMoveVector { get; private set; }
    public bool isMoving;
    public bool isRunning;

    protected override void Awake()
    {
        base.Awake();
        rigidBody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        InputManager.Singleton.OnUseToolPerformed += ExecuteUseTool;
        InputManager.Singleton.OnInteractPerformed += ExecuteInteract;
        InputManager.Singleton.OnInventoryTogglePerformed += ExecuteInventoryToggle;
        InputManager.Singleton.OnCraftTabTogglePerformed += ExecuteCraftTabToggle;
        InputManager.Singleton.OnEquipmentTabTogglePerformed += ExecuteEquipmentTabToggle;
        InputManager.Singleton.OnRunTogglePerformed += ExecuteRunToggle;
    }

    private void OnDestroy()
    {
        InputManager.Singleton.OnUseToolPerformed -= ExecuteUseTool;
        InputManager.Singleton.OnInteractPerformed -= ExecuteInteract;
        InputManager.Singleton.OnInventoryTogglePerformed -= ExecuteInventoryToggle;
        InputManager.Singleton.OnCraftTabTogglePerformed -= ExecuteCraftTabToggle;
        InputManager.Singleton.OnEquipmentTabTogglePerformed -= ExecuteEquipmentTabToggle;
        InputManager.Singleton.OnRunTogglePerformed -= ExecuteRunToggle;
    }

    private void ExecuteUseTool()
    {
        if (PlayerCharacter.Singleton.DisableCharacterControl.IsDisabled)
            return;

        if (toolController.UseToolWorld())
            return;

        toolController.UseToolGrid();
    }

    private void ExecuteInteract()
    {
        if (PlayerCharacter.Singleton.DisableCharacterControl.IsDisabled)
            return;

        interaction.Interact();
    }

    private void ExecuteInventoryToggle()
    {
        UIManager.Singleton.ToggleUI<InventoryUI>(UIType.Inventory);
    }

    private void ExecuteCraftTabToggle()
    {
        UIManager.Singleton.ToggleUI<CraftUI>(UIType.Craft);
    }

    private void ExecuteEquipmentTabToggle()
    {
        UIManager.Singleton.ToggleUI<EquipmentUI>(UIType.TempEquipment);
    }

    private void ExecuteRunToggle()
    {
        isRunning = !isRunning;
        animator.SetBool("isRunning", isRunning);
    }

    private void Update()
    {
        Vector2 input = InputManager.Singleton.MovementInput;
        Move(input);

        float horizontal = input.x;
        float vertical = input.y;

        if (horizontal < 0 || lastMoveVector.x < 0)
            spriteRenderer.flipX = true;
        else
            spriteRenderer.flipX = false;

        animator.SetFloat("Horizontal", horizontal);
        animator.SetFloat("Vertical", vertical);

        isMoving = (horizontal != 0 || vertical != 0);
        animator.SetBool("isMoving", isMoving);

        if (isMoving)
        {
            lastMoveVector = input.normalized;
            animator.SetFloat("lastHorizontal", horizontal);
            animator.SetFloat("lastVertical", vertical);
        }
    }

    public void Move(Vector2 input)
    {
        rigidBody.velocity = input * PlayerCharacter.Singleton.CharacterAttributeComponent.GetAttributeCurrentValue(AttributeTypes.MoveSpeed);
        if (isRunning)
            rigidBody.velocity *= 1.5f;
    }

    private void OnDisable()
    {
        rigidBody.velocity = Vector2.zero;
    }

    private void OnEnable()
    {
        animator.Play("Idle", 0, 0f);
    }
}
