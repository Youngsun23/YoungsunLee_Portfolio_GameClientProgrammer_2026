using UnityEngine;

public class CharacterAttribute : MonoBehaviour
{
    public float MaxValue => DefaultValue + ModifierValue;
    public float CurrentValue => DefaultValue + ModifierValue + BuffedValue;

    public float DefaultValue { get; set; } 
    public float ModifierValue { get; set; } 
    public float BuffedValue { get; set; }

    public System.Action<float, float> OnModifierChanged; 
    public System.Action<float, float> OnBuffedChanged; 
}