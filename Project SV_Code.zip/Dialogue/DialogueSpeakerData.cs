using UnityEngine;

[CreateAssetMenu(menuName = "Data/Dialogue/Speaker")]
public class DialogueSpeakerData : GameDataBase
{
    public Sprite Portrait => portrait;
    public string Name => speakerName;

    [SerializeField] private Sprite portrait;
    [SerializeField] private string speakerName;
}
