using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EquipmentType
{
    None,

    Head,
    Body,
    Tool,
    Shard,
    Shoes,

    Else
}

public interface IEquipable
{
    void ApplyEffect();
    void RemoveEffect();
}

[CreateAssetMenu (menuName = "Data/Item/Equipment")]
public class EquipItem : Item, IEquipable
{
    public SerializableDictionary<AttributeTypes, float> Effects => effects;
    public EquipmentType EquipmentType => equipmentType;

    [SerializeField] private SerializableDictionary<AttributeTypes, float> effects;
    [SerializeField] private EquipmentType equipmentType;

    public void ApplyEffect()
    {

    }

    public void RemoveEffect()
    {

    }
}
