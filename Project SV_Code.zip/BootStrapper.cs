using System.Collections.Generic;
using UnityEngine;

public class BootStrapper
{
    private static List<string> AutoBootStrappedScenes = new List<string>()
        {
            "Main",
            "Title",
            "Ingame",
        };

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    public static void SystemBoot()
    {
        InternalBoot();
    }

    private static void InternalBoot()
    {
        Debug.Log($"{nameof(InternalBoot)} 실행");

        UIManager.Singleton.Initialize();
    }
}