using UnityEngine;

public enum UIType
{
    PANEL_START,

    HUD,
    FadeInOut,

    PANEL_END,
    POPUP_START,

    Inventory,
    ToolBar,
    ToolTip,
    DragDrop,
    Dialogue,
    Time,
    TempButtons,
    TempCraft,
    TempEquipment,
    Craft,
    ChestInventory,
    Trade,

    POPUP_END,
}


public abstract class UIBase : MonoBehaviour
{
    public virtual void Show()
    {
        gameObject.SetActive(true);
    }

    public virtual void Hide()
    {
        gameObject.SetActive(false);
    }
}
