using System.Collections;
using UnityEditor;
using UnityEngine;

public class TitleUI : MonoBehaviour
{
    public void OnClickGamePlayButton()
    {
        StartCoroutine(ChangeSceneDelay());
    }

    public void OnClickGameResetButton()
    {
#if UNITY_EDITOR
        UserDataManager.Singleton.Delete();
#else
        UserDataManager.Singleton.BuildDelete();
#endif
    }

    IEnumerator ChangeSceneDelay()
    {
        var FadeUI = UIManager.Singleton.GetUI<FadeInOutUI>(UIType.FadeInOut);
        FadeUI.FadeOut();
        yield return new WaitForSeconds(2f);
        Main.Singleton.ChangeScene(SceneType.Ingame);
    }

    public void OnClickGameQuitButton()
    {
#if UNITY_EDITOR
        EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
    }
}
