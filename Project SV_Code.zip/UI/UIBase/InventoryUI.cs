public class InventoryUI : UIBase
{
    public override void Show()
    {
        base.Show();

        PlayerCharacter.Singleton.DisableCharacterControl.DisableControl();
        UIManager.Hide<ToolBarUI>(UIType.ToolBar);
    }

    public override void Hide()
    {
        base.Hide();

        PlayerCharacter.Singleton.DisableCharacterControl.EnableControl();
        UIManager.Show<ToolBarUI>(UIType.ToolBar);
    }
}
