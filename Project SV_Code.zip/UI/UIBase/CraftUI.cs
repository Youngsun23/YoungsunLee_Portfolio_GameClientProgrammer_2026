public class CraftUI : UIBase
{
    public override void Show()
    {
        base.Show();

        PlayerCharacter.Singleton.DisableCharacterControl.DisableControl();
        UIManager.Show<InventoryUI>(UIType.Inventory);
    }

    public override void Hide()
    {
        base.Hide();

        PlayerCharacter.Singleton.DisableCharacterControl.EnableControl();
        UIManager.Hide<InventoryUI>(UIType.Inventory);
    }
}
