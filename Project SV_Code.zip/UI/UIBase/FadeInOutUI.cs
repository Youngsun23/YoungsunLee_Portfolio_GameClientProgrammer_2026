using Sirenix.OdinInspector;
using UnityEngine;

public class FadeInOutUI : UIBase
{
    public CanvasGroup canvasGroup;
    public float fadeDuration = 1.0f;
    public AnimationCurve fadeInCurve;
    public AnimationCurve fadeOutCurve;
    private AnimationCurve currentCurve;
    private bool isFading = false;
    private float fadeStartTime;
    private bool doneFadeIn = false;

    private void Update()
    {
        if (isFading)
        {
            float elapsedTime = Time.time - fadeStartTime;
            float t = Mathf.Clamp01(elapsedTime / fadeDuration);

            canvasGroup.alpha = currentCurve.Evaluate(t);

            if (t >= 1.0f)
            {
                isFading = false;
            }
        }
    }

    [Button("Fade In")]
    public void FadeIn()
    {
        doneFadeIn = true;
        StartFade(fadeInCurve);
    }

    [Button("Fade Out")]
    public void FadeOut()
    {
        doneFadeIn = false;
        StartFade(fadeOutCurve);
    }

    private void StartFade(AnimationCurve curve)
    {
        this.currentCurve = curve;
        this.fadeStartTime = Time.time;
        this.isFading = true;
    }
}
