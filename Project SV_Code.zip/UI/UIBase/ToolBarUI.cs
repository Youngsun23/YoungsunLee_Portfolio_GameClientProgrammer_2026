using UnityEngine;

public class ToolBarUI : UIBase
{
    [SerializeField] private ToolBarPanel toolBarPanel;

    public override void Show()
    {
        base.Show();

        toolBarPanel.Show();
    }
}
