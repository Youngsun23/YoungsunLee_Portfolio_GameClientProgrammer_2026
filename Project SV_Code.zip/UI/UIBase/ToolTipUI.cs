public class ToolTipUI : UIBase
{

}
