using System;
using UnityEngine;

public class ChestInventoryUI : UIBase
{
    public Action onChestClosed;

    [SerializeField] private ChestInventoryPanel panel;

    public ChestInventoryPanel GetPanel() => panel;

    public override void Show()
    {
        base.Show();

        PlayerCharacter.Singleton.DisableCharacterControl.DisableControl();
        UIManager.Show<InventoryUI>(UIType.Inventory);
    }

    public override void Hide()
    {
        base.Hide();

        PlayerCharacter.Singleton.DisableCharacterControl.EnableControl();
        UIManager.Hide<InventoryUI>(UIType.Inventory);

        onChestClosed?.Invoke();
    }

    public void OnClickChestExitButton()
    {
        Hide();
    }
}
