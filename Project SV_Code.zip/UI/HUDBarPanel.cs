using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class HUDBarPanel : MonoBehaviour
{

    [SerializeField] private Image HPBar;
    [SerializeField] private Image StaminaBar;

    public void UpdateHUDUI()
    {

    }

    public void UpdateHUDUIHP(float maxHP, float curHP)
    {
        float targetFill = curHP / maxHP;
        targetFill = Mathf.Clamp01(targetFill);
        StartCoroutine(FillBar(targetFill, HPBar));
    }

    public void UpdateHUDUIStamina(float maxStamina, float curStamina)
    {
        if (curStamina <= 0)
            curStamina = 0f;

        float targetFill = curStamina / maxStamina;
        targetFill = Mathf.Clamp01(targetFill);
        StartCoroutine(FillBar(targetFill, StaminaBar));
    }

    private IEnumerator FillBar(float targetFill, Image bar)
    {
        float duration = 2f;
        float elapsed = 0f;
        float startFill = bar.fillAmount;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            bar.fillAmount = Mathf.Lerp(startFill, targetFill, t);
            yield return null;
        }

        bar.fillAmount = targetFill;
    }
}
