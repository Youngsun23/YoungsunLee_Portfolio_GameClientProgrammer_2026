using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TileMapReadManager : SingletonBase<TileMapReadManager>
{
    public Tilemap TargetMap => readTargetTileMap;
    [SerializeField] private Tilemap readTargetTileMap;
    [SerializeField] private List<TileData> tileData;
    private Dictionary<TileBase, TileData> dataFromTiles;

    private void Start()
    {
        dataFromTiles = new Dictionary<TileBase, TileData>();

        foreach (TileData data in tileData)
        {
            foreach (TileBase tile in data.Tiles)
            {
                dataFromTiles.TryAdd(tile, data);
            }
        }
    }

    public void SetReadTargetTileMap(Tilemap target)
    {
        readTargetTileMap = target;
    }

    public Vector3Int GetGridPosition(Vector2 mousePos, bool useMouse = true)
    {
        if (readTargetTileMap == null)
        {
            return Vector3Int.zero;
        }

        Vector3 worldPos;

        if (useMouse)
        {
            worldPos = Camera.main.ScreenToWorldPoint(mousePos);
        }
        else
        {
            worldPos = mousePos;
        }

        Vector3Int gridPos = readTargetTileMap.WorldToCell(worldPos);
        return gridPos;
    }

    public TileBase GetTileBase(Vector3Int gridPos)
    {
        TileBase tile = readTargetTileMap.GetTile(gridPos);

        return tile;
    }

    public TileData GetTileData(TileBase tileBase)
    {
        if (readTargetTileMap == null)
        {
            return null;
        }

        if (tileBase != null)
        {
            dataFromTiles.TryGetValue(tileBase, out TileData tileData);
            return tileData;
        }
        return null;
    }
}
