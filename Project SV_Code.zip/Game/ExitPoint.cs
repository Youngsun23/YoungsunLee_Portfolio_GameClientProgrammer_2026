using UnityEngine;

public class ExitPoint : MonoBehaviour, IInteractable
{
    [SerializeField] private string destinationScene;
    [SerializeField] private Vector2 destinationPosition;

    public void Interact(PlayerCharacterController character)
    {
        if (SceneTransitionManager.Singleton.IsLoading)
            return;
        SceneTransitionManager.Singleton.LoadLevel(destinationScene, destinationPosition);
    }
}