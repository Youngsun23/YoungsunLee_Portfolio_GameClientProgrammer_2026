using UnityEngine;
using UnityEngine.Tilemaps;

public class EntryPoint : MonoBehaviour
{
    [SerializeField] private Tilemap plowMap;
    [SerializeField] private Tilemap plantMap;
    [SerializeField] private Tilemap readMap;
    [SerializeField] private Tilemap highlightMap;
    [SerializeField] private Tilemap placedItemMap;

    [SerializeField] private Collider2D confiner;

    private void Awake()
    {
        if (plowMap != null)
            CropManager.Singleton.SetPlowTargetTileMap(plowMap);
        if (plantMap != null)
            CropManager.Singleton.SetPlantTargetTileMap(plantMap);
        if (readMap != null)
            TileMapReadManager.Singleton.SetReadTargetTileMap(readMap);
        if (highlightMap != null)
            GameManager.Singleton.PlaceableItemHighlight.SetTargetTileMap(highlightMap);
        if (placedItemMap != null)
        {
            PlaceableObjectsManager.Singleton.SetTargetTileMap(placedItemMap);
            if (!PlaceableObjectsManager.Singleton.isInitialized)
            {
                PlaceableObjectsManager.Singleton.Initialize();
                PlaceableObjectsManager.Singleton.SetInitialized(true);
            }
            else
            {
                PlaceableObjectsManager.Singleton.InitilizeScene();
            }
        }
    }

    private void OnEnable()
    {
        if (confiner != null)
        {
            CameraSystem.Singleton.SetCameraConfiner(confiner);
        }
    }
}
