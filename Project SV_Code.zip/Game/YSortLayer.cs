using UnityEngine;

public class YSortLayer : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    private float lastY;
    private float pivotOffsetY = 0f;
    [SerializeField] private bool isStatic = false;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        lastY = transform.position.y;
        pivotOffsetY = spriteRenderer.bounds.size.y / 2;
        UpdateOrder();
    }

    void LateUpdate()
    {
        if (isStatic)
            return;

        float y = transform.position.y;
        if (Mathf.Abs(y - lastY) > 0.001f)
        {
            UpdateOrder();
            lastY = y;
        }
    }

    void UpdateOrder()
    {
        float y = transform.position.y - pivotOffsetY;
        spriteRenderer.sortingOrder = Mathf.RoundToInt(-y * 100);
    }
}
