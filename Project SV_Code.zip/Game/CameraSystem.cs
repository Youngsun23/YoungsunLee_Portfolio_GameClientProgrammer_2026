using Cinemachine;
using UnityEngine;

public class CameraSystem : SingletonBase<CameraSystem>
{
    public CinemachineConfiner2D Confiner => cameraConfiner;
    [SerializeField] private CinemachineConfiner2D cameraConfiner;

    public void SetCameraConfiner(Collider2D collider)
    {
        cameraConfiner.m_BoundingShape2D = collider;
        cameraConfiner.InvalidateCache();
    }
}
