using UnityEngine;
using UnityEngine.Tilemaps;

public class PlaceableItemHighlight : MonoBehaviour
{
    private Vector3Int targetCellPosition;
    private Vector3 targetWorldPosition;
    [SerializeField] private Tilemap targetTileMap;
    private SpriteRenderer spriteRenderer;
    private bool isTileSelectable;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (targetTileMap == null) return;

        targetWorldPosition = targetTileMap.CellToWorld(targetCellPosition);
        transform.position = targetWorldPosition + targetTileMap.cellSize / 2;
    }

    public void SetTargetCellPosition(Vector3Int pos)
    {
        this.targetCellPosition = pos;
    }

    public void SetTargetTileMap(Tilemap target)
    {
        targetTileMap = target;
    }

    public void SetIcon(Sprite icon)
    {
        if (spriteRenderer == null) spriteRenderer = GetComponent<SpriteRenderer>(); 

        spriteRenderer.sprite = icon;
    }

    public void Show(bool show)
    {
        gameObject.SetActive(show);
    }
}
