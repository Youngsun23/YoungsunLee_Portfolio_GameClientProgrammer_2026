using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(TimeAgent))]
public class ObjectSpawner : TimeAgent
{
    [SerializeField] private float spawnAreaHeight = 1;
    [SerializeField] private float spawnAreaWidth = 1;
    [SerializeField] private GameObject[] objectToSpawn;
    [SerializeField] private Item[] itemToSpawn;
    private int length;
    [SerializeField] private float probability = 0.1f;
    [SerializeField] private int spawnCount = 1;
    [SerializeField] private bool oneTime = false;
    [SerializeField] private int objectSpawnLimit = -1;
    [SerializeField] private int spawnedObjectCount = 0;
    public Tilemap targetTilemap;

    protected override void Start()
    {
        length = objectToSpawn.Length;
        if (!oneTime)
        {
            base.Start();
            onTimeTick += Tick;
        }
        else
        {
            Tick();
        }
    }

    protected override void OnDestroy()
    {
        if (!oneTime)
        {
            base.OnDestroy();
            onTimeTick -= Tick;
        }
    }

    public void Tick()
    {
        if (Random.value > probability) return;
        if (objectSpawnLimit != -1 && objectSpawnLimit <= spawnedObjectCount) return;

        for (int i = 0; i < spawnCount; i++)
        {
            int id = Random.Range(0, length);
            GameObject spawnedObject = Instantiate(objectToSpawn[id]);

            spawnedObject.transform.position = transform.position;
            Scene targetScene = SceneManager.GetSceneByName("Cave1");
            SceneManager.MoveGameObjectToScene(spawnedObject, targetScene);
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;

        Vector3 minWorld = transform.position - new Vector3(spawnAreaWidth, spawnAreaHeight, 0f);
        Vector3 maxWorld = transform.position + new Vector3(spawnAreaWidth, spawnAreaHeight, 0f);

        Vector3Int minCell = targetTilemap.WorldToCell(minWorld);
        Vector3Int maxCell = targetTilemap.WorldToCell(maxWorld);

        Vector3 snappedMin = targetTilemap.CellToWorld(minCell);
        Vector3 snappedMax = targetTilemap.CellToWorld(maxCell + Vector3Int.one);

        Vector3 center = (snappedMin + snappedMax) / 2f;
        Vector3 size = snappedMax - snappedMin;

        Gizmos.DrawWireCube(center, size);
    }
}