using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransitionManager : SingletonBase<SceneTransitionManager>
{
    private string currentLevelName;

    private Vector2 startPoint = new Vector2(-6.5f, -1.5f);

    private bool isInitialized = false;
    public bool IsLoading { get; private set; } = false;

    private void Start()
    {
        if (string.IsNullOrEmpty(currentLevelName))
        {
            LoadLevel("Farm", startPoint);
        }
    }

    public void LoadLevel(string levelName, Vector2 pos)
    {
        StartCoroutine(LoadLevelAsync(levelName, pos));
    }

    IEnumerator LoadLevelAsync(string levelName, Vector2 pos)
    {
        IsLoading = true;

        PlayerCharacter.Singleton.DisableCharacterControl.DisableControl();

        var FadeUI = UIManager.Singleton.GetUI<FadeInOutUI>(UIType.FadeInOut);
        if (!string.IsNullOrEmpty(currentLevelName))
        {
            FadeUI.Show();
            FadeUI.FadeOut();
            yield return new WaitForSeconds(1);

            var unloadAsync = SceneManager.UnloadSceneAsync(currentLevelName);
            while (!unloadAsync.isDone)
            {
                yield return null;
            }
            currentLevelName = string.Empty;
        }

        currentLevelName = levelName;
        var loadAsync = SceneManager.LoadSceneAsync(currentLevelName, LoadSceneMode.Additive);
        while (!loadAsync.isDone)
        {
            yield return null;
        }
        Scene loadedScene = SceneManager.GetSceneByName(currentLevelName);
        SceneManager.SetActiveScene(loadedScene);

        PlaceableObjectsManager.Singleton.SaveRuntimePlacedItemsData();

        var player = PlayerCharacter.Singleton.GetComponent<PlayerCharacterToolController>();
        var marker = FindObjectOfType<MarkerManager>();
        player?.SetMarkerManager(marker);

        PlayerCharacterController.Singleton.transform.position = pos;
        PlayerCharacter.Singleton.DisableCharacterControl.EnableControl();

        if (!isInitialized)
        {
            TimeManager.Singleton.StartNewDay();
            isInitialized = true;
        }
        yield return new WaitForSeconds(1.5f);
        FadeUI.FadeIn();
        yield return new WaitForSeconds(2f);
        FadeUI.Hide();

        IsLoading = false;
    }
}
