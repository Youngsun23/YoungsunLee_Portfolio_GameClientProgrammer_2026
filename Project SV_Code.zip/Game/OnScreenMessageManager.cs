using TMPro;
using UnityEngine;

public class OnScreenMessageManager : SingletonBase<OnScreenMessageManager>
{
    [SerializeField] private GameObject textPrefab;
    private float timeOnScreen = 1f;

    public void ShowMessageOnScreen(Vector3 worldPos, string message)
    {
        worldPos.x += Random.Range(-0.5f, 0.5f);
        worldPos.y += Random.Range(-0.5f, 0.5f);

        GameObject textGO = Instantiate(textPrefab, transform);
        textGO.transform.position = worldPos;

        TextMeshPro tmp = textGO.GetComponent<TextMeshPro>();
        tmp.text = message;

        Destroy(textGO, timeOnScreen);
    }
}
