using UnityEngine;

namespace HAD
{
    public class LevelEntryPoint : MonoBehaviour
    {
        private void Awake()
        {
            GameManager.Instance.AddEntryPoint(this);
        }
    }
}
