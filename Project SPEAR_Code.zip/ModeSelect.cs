using UnityEngine;

public class ModeSelect : MonoBehaviour
{
    public bool invincibleMode = false;
    public GameObject invincibleIcon;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            if (invincibleMode)
            {
                invincibleMode = false;
            }
            else
            {
                invincibleMode = true;
            }
        }
    }
}
