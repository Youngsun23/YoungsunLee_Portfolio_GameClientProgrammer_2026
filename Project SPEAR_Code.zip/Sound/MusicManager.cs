using UnityEngine;

public class MusicManager : MonoBehaviour
{
    public enum STAGE
    {
        MONSTER,
        NAMED,
        BOSS,
        CLEAR,
        OVER
    }

    private STAGE stage = STAGE.MONSTER;
    public AudioSource BGMMonster;
    public AudioSource BGMNamed;
    public AudioSource BGMBoss;
    public AudioSource BGMClear;
    public AudioSource BGMOver;

    public float fadeDuration;

    public void Start()
    {
        BGMMonster.volume = 1f;
        BGMNamed.volume = 0f;
        BGMBoss.volume = 0f;
        BGMClear.gameObject.SetActive(false);
        BGMOver.gameObject.SetActive(false);
    }

    public void BGMChange(STAGE _stage)
    {
        switch (_stage)
        {
            case STAGE.MONSTER:
                stage = STAGE.MONSTER;
                break;
            case STAGE.NAMED:
                stage = STAGE.NAMED;
                break;
            case STAGE.BOSS:
                stage = STAGE.BOSS;
                break;
            case STAGE.CLEAR:
                stage = STAGE.CLEAR;
                break;
            case STAGE.OVER:
                stage=STAGE.OVER;
                break;
        }
    }

    public void Update()
    {
        switch (stage)
        {
            case STAGE.MONSTER:
                if (BGMMonster.volume < 1f)
                    volUp(BGMMonster, 1f);
                if (BGMNamed.volume > 0f)
                    volDown(BGMNamed, 0f);
                break;
            case STAGE.NAMED:
                if (BGMNamed.volume < 1f)
                    volUp(BGMNamed, 1f);
                if (BGMMonster.volume > 0f)
                    volDown(BGMMonster, 0f);
                break;
            case STAGE.BOSS:
                if (BGMBoss.volume < 0.6f)
                    volUp(BGMBoss, 0.6f);
                if (BGMMonster.volume > 0f)
                    volDown(BGMMonster, 0f);
                break;
            case STAGE.CLEAR:
                BGMClear.gameObject.SetActive(true);
                if (BGMBoss.volume > 0f)
                    volDown(BGMBoss, 0f);
                break;
            case STAGE.OVER:
                BGMOver.gameObject.SetActive(true);
                if (BGMMonster.gameObject.activeSelf)
                    BGMMonster.gameObject.SetActive(false);
                if (BGMNamed.gameObject.activeSelf)
                    BGMNamed.gameObject.SetActive(false);
                if (BGMBoss.gameObject.activeSelf)
                    BGMBoss.gameObject.SetActive(false);
                break;
        }
    }

    private void volUp(AudioSource source, float _targetVol)
    {
        float increaseAmount = 1f / fadeDuration * Time.deltaTime;
        if (source != BGMMonster)
        {
            source.Stop();
            source.Play();
        }
        source.volume = Mathf.Min(_targetVol, source.volume + increaseAmount);
    }
    private void volDown(AudioSource source, float _targetVol)
    {
        float decreaseAmount = 1f / fadeDuration * Time.deltaTime;
        source.volume = Mathf.Max(_targetVol, source.volume - decreaseAmount);
    }
}
