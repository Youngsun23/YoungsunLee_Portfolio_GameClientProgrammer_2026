using System.Collections;
using UnityEngine;

public class BambooDestroy : MonoBehaviour
{
    private AudioSource sound;
    void Start()
    {
        sound = GetComponent<AudioSource>();
        sound.Play();
        StartCoroutine("SoundDestroy");
    }

    IEnumerator SoundDestroy()
    {
        yield return new WaitForSeconds(sound.time + 2f);
        Destroy(gameObject);
    }
}
