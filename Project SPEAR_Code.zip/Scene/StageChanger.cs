using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;
public class StageChanger : MonoBehaviour
{
    public bool isPlay;
    public StageChanger SC;

    public bool easy;
    public bool normal;
    public bool hard;
    
    private void Start()
    {
        isPlay = true;
        easy = false;
        normal = false;
        hard = false;
    }

    public void easyMode()
    {
        easy = true;

        if (easy)
        {
            Invoke("EnterEasy", 2f);
        }
    }

    private void EnterEasy()
    {
        SceneManager.LoadScene("Easy");
    }

    public void normalMode()
    {
        normal = true;
        if (normal)
        {
            Invoke("EnterNormal", 2f);
        }
    }

    private void EnterNormal()
    {
        SceneManager.LoadScene("Normal");
    }

    public void hardMode()
    {
        hard = true;
        if (hard)
        {
            Invoke("EnterHard", 2f);
        }
    }

    private void EnterHard()
    {
        SceneManager.LoadScene("Hard");
    }
}
