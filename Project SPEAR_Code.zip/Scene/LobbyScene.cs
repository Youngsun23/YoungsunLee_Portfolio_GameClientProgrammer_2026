using UnityEngine;

public class LobbyScene : MonoBehaviour
{
    private StageChanger stageChanger;
    public GameObject Vd;

    public float rotationSpeed;            
    public float moveSpeed;                

    public bool fadeoutTrigger = false;     

    public bool press = false;            
    private bool isMoving = true;         

    public GameObject gamelogo;
    public GameObject presstext;
    public GameObject gamesource;
    public GameObject easyButton;
    public GameObject normalButton;
    public GameObject hardButton;

    private Vector3 lastMousePosition;
    private float elapsedTime;
    public float checkCount;

    private void Start()
    {
        easyButton.SetActive(false);
        normalButton.SetActive(false);
        hardButton.SetActive(false);
        stageChanger = GameObject.FindWithTag("test").GetComponent<StageChanger>();

        Vd.SetActive(false);
        elapsedTime = 0.0f;
        lastMousePosition = Input.mousePosition;
    }

    void Update()
    {
        Vector3 curmousePosition = Input.mousePosition;

        if (curmousePosition != lastMousePosition)
        {
            elapsedTime = 0.0f;
            lastMousePosition = curmousePosition;
            Vd.SetActive(false);
        }
        else
        {
            elapsedTime += Time.deltaTime;

            if (elapsedTime >= checkCount && press == false)
            {
                Vd.SetActive(true);
            }
        }

        if (Time.timeScale == 0)
        {
            Time.timeScale = 1;
        }

        transform.Rotate(Vector3.forward, -rotationSpeed * Time.deltaTime);

        if ((Vd.activeSelf == false && !press) && (Input.anyKeyDown || Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1) || Input.GetMouseButtonDown(2)))
        {
            press = true;

            gamesource.SetActive(false);
        }

        if (press && isMoving)
        {
            gamelogo.SetActive(false);
            presstext.SetActive(false);

            Vector3 movement = Vector3.right;

            transform.position += movement * moveSpeed * Time.deltaTime;

            if (transform.position.x >= 0)
            {
                easyButton.SetActive(true);
                normalButton.SetActive(true);
                hardButton.SetActive(true);

                isMoving = false;
            }
        }

        if (!isMoving && stageChanger.easy || stageChanger.normal || stageChanger.hard)
        {
            easyButton.SetActive(false);
            normalButton.SetActive(false);
            hardButton.SetActive(false);

            rotationSpeed = 50f;

            fadeoutTrigger = true;
        }
    }
}
