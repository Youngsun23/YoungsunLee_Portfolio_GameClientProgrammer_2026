using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHeal : MonoBehaviour
{
    public float moveDuration = 3.0f;
    public int healCost = 1;

    private Vector3 startPosition;
    private Vector3 endPosition;
    private float startTime;
    private GameObject Player;

    private void Start()
    {
        Player = GameObject.Find("Player");

        startPosition = new Vector3(11f, 0f, 0f);
        endPosition = new Vector3(-11f, 0f, 0f);

        startTime = Time.time;

        StartCoroutine(Move());
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Spear"))
        {
            Destroy(gameObject);
        }
    }

    IEnumerator Move()
    {
        float elapsedTime = 0f;

        while (elapsedTime < moveDuration)
        {
            elapsedTime = Time.time - startTime;

            float t = Mathf.Clamp01(elapsedTime / moveDuration);
            transform.position = Vector3.Lerp(startPosition, endPosition, t);

            yield return null;
        }

        Destroy(gameObject);
    }
}
