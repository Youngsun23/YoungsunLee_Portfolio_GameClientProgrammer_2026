using UnityEngine;
using System.Collections;
using UnityEngine.UIElements;

public class PlayerManager : MonoBehaviour
{
    public float moveSpeed = 15f;    
    public float jumpForce = 15f;    
    private bool isJumping = false; 
    public Rigidbody2D rb;
    private SpriteRenderer spriteRenderer;
    private GameObject Parent;
    public GameObject JumpEffectPrefab;
    public MapRotation rotate;

    public bool canMove = true;

    public Animator playerAnimator;
    public bool PlayerState = false;

    public AudioSource JumpSound;

    private PlayerHealthPlusUI playerui;

    private void Start()
    {
        playerAnimator = GetComponent<Animator>();
        Parent = GameObject.Find("WaveManager");
        playerui = FindObjectOfType<PlayerHealthPlusUI>();
    }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (!playerui.GameIsPaused)
        {
            if (canMove)
            {
                rotate.GetComponent<MapRotation>().rotationSpeed = 105f;

                float moveDirection = Input.GetAxis("Horizontal"); 
                                                                   
                if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
                {
                    playerAnimator.SetBool("isMoving", true);
                }
                else
                {
                    playerAnimator.SetBool("isMoving", false);
                }

                if (Input.GetButtonDown("Jump") && !isJumping) 
                {
                    JumpSound.Play();
                    playerAnimator.SetBool("isJumping", true);
                    rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse); 
                    isJumping = true; 

                    GameObject JumpEffect = Instantiate(JumpEffectPrefab, transform.position, Quaternion.identity, Parent.transform.parent);

                    StartCoroutine(DestroyJumpEffect(JumpEffect));
                }

                UpdateFacingDirection();
            }
        }
    }

    public void dead()
    {
        PlayerState = true;
        rotate.GetComponent<MapRotation>().rotationSpeed = 0f;
        GetComponentInChildren<Spear>().DeadSpearState = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Floor")) 
        {
            playerAnimator.SetBool("isJumping",false);
            isJumping = false;
        }
    }

    private void UpdateFacingDirection()
    {
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        float horizontalDistance = mousePosition.x - transform.position.x;

        if (horizontalDistance > 0) 
        {
            spriteRenderer.flipX = false; 
        }
        else if (horizontalDistance < 0) 
        {
            spriteRenderer.flipX = true; 
        }
    }

    IEnumerator DestroyJumpEffect(GameObject JumpEffect)
    {
        yield return new WaitForSeconds(0.333f);

        Destroy(JumpEffect);
    }
}