using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class PlayerHealthPlusUI : TransparentState
{
    public GameObject halfTransBackground;
    public GameObject waveBar;
    public GameObject bossBar;

    public MusicManager musicManager;

    private Animator playerAnimator;
    public GameObject PHitEffectPrefab;
    public GameObject Boss;

    public AudioSource MenuOpenSound;
    public AudioSource MenuCloseSound;
    public AudioSource PierceSound;
    public AudioSource ThrowSound;
    public AudioSource DamagedSound;

    private GameObject waveManager; 
    public PlayerManager playermanager;
    public Spear spear;

    public int maxHP = 5;
    public int currentHP;
    public int monsterCount;

    public float AutoHealCooltime = 7f;
    private float currentAutoHealCooltime;

    public int AutoHealCost = 1;

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    private bool isInvincible = false;
    private float invincibleTimer = 0f;
    public float invincibleDuration = 1f;

    public GameObject PauseMenuUI;
    public GameObject ClearMenuUI;
    public GameObject OverMenuUI;

    public bool GameIsPaused;
    public bool isGameEnd = false;
    private bool isDieTriggered = false;
    private bool isPierceSoundPlaying = false;

    private ModeSelect modeSelect;

    int _roundNum;
    int _setNum;
    int _objNum;

    public int hits;
    public float clearTime;
    public int minutes;
    public int seconds;
    public bool comboCut;
    public bool justRestarted = false;

    private void Start()
    {
        musicManager = GameObject.Find("BGMManager").GetComponent<MusicManager>();

        currentAutoHealCooltime = AutoHealCooltime;
        currentHP = maxHP;
        spriteRenderer = GetComponent<SpriteRenderer>();
        waveManager = GameObject.Find("WaveManager");

        PauseMenuUI.gameObject.SetActive(false);
        ClearMenuUI.gameObject.SetActive(false);
        OverMenuUI.gameObject.SetActive(false);

        Time.timeScale = 1f;
        GameIsPaused = false;

        EnablePlayerInput();
        EnableSpearInput();

        playerAnimator = GetComponent<Animator>();
        modeSelect = FindObjectOfType<ModeSelect>();
    }

    private void Update()
    {
        UpdateHealthUI();

        if (currentHP < 5 && !GameIsPaused)
        {
            AutoHeal();
        }

        if (Input.GetKeyDown(KeyCode.F2))
        {
            currentHP += 1;
            if (currentHP > 5)
            {
                currentHP = 5;
            }
        }

        if (spear.isPiercing)
        {
            if (!isPierceSoundPlaying)
            {
                isPierceSoundPlaying = true;
                StartCoroutine(PlayPierceSound());
            }

            spear.isPiercing = false;
        }

        IEnumerator PlayPierceSound()
        {
            PierceSound.Play();
            yield return new WaitForSeconds(PierceSound.clip.length); 
            isPierceSoundPlaying = false;
        }

        if (spear.isThrowing)
        {
            ThrowSound.Play();
            spear.isThrowing = false;
        }

        if (isInvincible && Time.timeScale > 0f)
        {
            invincibleTimer -= Time.deltaTime;

            if (invincibleTimer <= 0f)
            {
                isInvincible = false;
                spriteRenderer.enabled = true;
            }
            else if (!isGameEnd)
            {
                spriteRenderer.enabled = !spriteRenderer.enabled;
            }

            UpdateHealthUI();
        }

        if (!isDieTriggered && !isGameEnd)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (GameIsPaused)
                {
                    ResumeGame();
                }
                else
                {
                    PauseGame();
                }
            }
        }

        if (Boss == null)
        {
            clearTime = Time.timeSinceLevelLoad;
            minutes = Mathf.FloorToInt(clearTime / 60);
            seconds = Mathf.FloorToInt(clearTime % 60);
            StartCoroutine(Clear());
        }
    }

    IEnumerator Clear()
    {
        yield return new WaitForSeconds(0.3f);
        GameClear();
    }


    private void OnTriggerStay2D(Collider2D collision)
    {
        TransparentState transparentState = collision.GetComponent<TransparentState>();

        if (!isDieTriggered)
        {
            if (transparentState == null)
            {
                if (collision.CompareTag("Bullet_enemy") && !isInvincible)
                {
                    TakeDamage(1);
                    StartInvincibility();
                    Destroy(collision.gameObject);
                }
                if (collision.CompareTag("Bullet_boss") && !isInvincible)
                {
                    TakeDamage(1);
                    StartInvincibility();
                    collision.gameObject.SetActive(false);
                }
                if (collision.CompareTag("Boss") && !isInvincible)
                {
                    TakeDamage(1);
                    StartInvincibility();
                }
                if (collision.CompareTag("poop") && !isInvincible)
                {
                    TakeDamage(1);
                    StartInvincibility();
                    collision.gameObject.SetActive(false);
                }
            }
        }
    }

    void AutoHeal()
    {
        currentAutoHealCooltime -= Time.deltaTime;
        if (currentAutoHealCooltime <= 0)
        {
            currentHP += AutoHealCost;
            if (currentHP > 5)
            {
                currentHP = 5;
            }
            currentAutoHealCooltime = AutoHealCooltime;
        }
    }

    public void TakeDamage(int damage)
    {
        comboCut = true;
        hits += damage;

        Vector3 offset = new Vector3(0f, 1.0f, 0f);
        GameObject PHItEffect = Instantiate(PHitEffectPrefab, transform.position + offset, Quaternion.identity);

        StartCoroutine(DestroyPHitEffect(PHItEffect));
        DamagedSound.Play();

        if (!modeSelect.invincibleMode)
        {
            currentHP -= damage;
        }

        if (currentHP <= 0 && !isDieTriggered)
        {
            isDieTriggered = true;
            playerAnimator.SetTrigger("Die");
            DisableSpearInput();
            DisablePlayerInput();

            StartCoroutine(GameOverCoroutine());
        }
        else if (!isDieTriggered)
        {
            playerAnimator.SetTrigger("Damaged");
        }
    }

    IEnumerator DestroyPHitEffect(GameObject PHitEffect)
    {
        yield return new WaitForSeconds(0.417f);

        Destroy(PHitEffect);
    }


    private IEnumerator GameOverCoroutine()
    {
        musicManager.BGMChange(MusicManager.STAGE.OVER);

        yield return new WaitForSeconds(0.5f);

        GameOver();
    } 

    public void StartInvincibility()
    {
        isInvincible = true;

        invincibleTimer = invincibleDuration;
        spriteRenderer.enabled = false;
    }

    private void GameOver()
    {
        if (waveBar != null)
        {
            waveBar.SetActive(false);
        }
        if (bossBar != null)
        {
            bossBar.SetActive(false);
        }
        OverMenuUI.gameObject.SetActive(true);
        MenuOpenSound.Play();
        Time.timeScale = 0f;
        GameIsPaused = true;
        isGameEnd = true;
        spriteRenderer.enabled = true;
    }

    private void GameClear()
    {
        if (isGameEnd)
        {
            return;
        }

        playerAnimator.enabled = false;
        halfTransBackground.SetActive(true);
        ClearMenuUI.gameObject.SetActive(true);
        MenuOpenSound.Play();
        GameIsPaused = true;
        isGameEnd = true;
        spriteRenderer.enabled = true;
        DisablePlayerInput();
        DisableSpearInput();
    }

    private void PauseGame()
    {
        spriteRenderer.enabled = true;
        PauseMenuUI.SetActive(true);
        MenuOpenSound.Play();
        Time.timeScale = 0f;
        GameIsPaused = true;

        DisablePlayerInput();
        DisableSpearInput();
    }

    private void DisablePlayerInput()
    {
        playermanager.canMove = false;
    }

    private void DisableSpearInput()
    {
        spear.canInput = false;
    }

    public void ResumeGame()
    {
        PauseMenuUI.SetActive(false);
        MenuCloseSound.Play();
        Time.timeScale = 1f;
        GameIsPaused = false;

        EnablePlayerInput();
        EnableSpearInput();
    }

    private void EnablePlayerInput()
    {
        playermanager.canMove = true;
    }

    private void EnableSpearInput()
    {
        spear.canInput = true;
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        justRestarted = true;
        PauseMenuUI.SetActive(false);
        ClearMenuUI.SetActive(false);
        OverMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;
        EnablePlayerInput();
        EnableSpearInput();
    }

    public void LoadLobby()
    {
        SceneManager.LoadScene("LobbyScene");
    }

    public void GameQuit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    private void UpdateHealthUI()
    {
        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < currentHP)
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;
            }

            if (i < maxHP)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }
        }
    }
}