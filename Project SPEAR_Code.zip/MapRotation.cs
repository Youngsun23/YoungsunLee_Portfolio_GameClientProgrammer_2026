using UnityEngine;

public class MapRotation : MonoBehaviour
{
    public float rotationSpeed = 105f;

    private PlayerHealthPlusUI healthPlusUI;

    private void Start()
    {
        healthPlusUI = FindObjectOfType<PlayerHealthPlusUI>();
    }

    private void Update()
    {
        if (healthPlusUI.isGameEnd)
        {
            rotationSpeed = 0f;
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(Vector3.forward, rotationSpeed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(Vector3.forward, -rotationSpeed * Time.deltaTime);
        }
    }
}