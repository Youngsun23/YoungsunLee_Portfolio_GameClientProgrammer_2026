using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseCursor : MonoBehaviour
{
    public RectTransform cursorUI; 
    public Texture2D customCursor; 

    void Start()
    {
        Cursor.visible = false;

        Cursor.SetCursor(customCursor, new Vector2(customCursor.width / 2f, customCursor.height / 2f), CursorMode.Auto);
    }

    void Update()
    {
        Vector3 mousePosition = Input.mousePosition;
        cursorUI.position = mousePosition;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.visible = false;
        }
    }
}




