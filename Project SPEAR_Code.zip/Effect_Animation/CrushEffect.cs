using System.Collections;
using UnityEngine;

public class CrushEffect : MonoBehaviour
{
    void Start()
    {
        gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        StartCoroutine("ForDestroy");
    }

    IEnumerator ForDestroy()
    {
        yield return new WaitForSeconds(0.3f);
        gameObject.SetActive(false);
    }
}
