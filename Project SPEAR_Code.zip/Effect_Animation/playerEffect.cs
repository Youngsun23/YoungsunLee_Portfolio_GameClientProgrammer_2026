using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerEffect : MonoBehaviour
{
    private PlayerManager playermanager;
    private Animator playereffectAnimator;
    private GameObject JumpEffect;
    private bool IsJumpTriggered;
    public Transform playerTransform;
    private WaveManager waveManager;
    public GameObject JumpEffectPrefab;
    private Vector3 JumpEffectPosition;

    private void Start()
    {
        playermanager = GetComponent<PlayerManager>();
        playereffectAnimator = JumpEffect.GetComponent<Animator>();
        playerTransform = GetComponent<Transform>();
        waveManager = GameObject.FindObjectOfType<WaveManager>();
    }

    void Update()
    {
        bool IsJumpTriggered()
        {
            return playermanager.playerAnimator.GetCurrentAnimatorStateInfo(0).IsName("Jump");
        }

        Vector3 GetJumpEffectPosition(Transform playerTransform)
        {
            Vector3 playerPosition = playerTransform.position;
            Vector3 jumpEffectPosition = new Vector3(playerPosition.x, playerPosition.y - 3f, playerPosition.z);

            return jumpEffectPosition;
        }

        if (IsJumpTriggered())
        {
            Vector3 JumpEffectPosition = GetJumpEffectPosition(playerTransform);
            GameObject JumpEffect = Instantiate(JumpEffectPrefab, JumpEffectPosition, Quaternion.identity);
            playereffectAnimator.SetTrigger("Jump");

            StartCoroutine(DestroyJumpEffect(JumpEffect));
        }

        IEnumerator DestroyJumpEffect (GameObject JumpEffect)
        {
            yield return new WaitForSeconds(2.75f);

            Destroy(JumpEffect);
        }
    }
}
