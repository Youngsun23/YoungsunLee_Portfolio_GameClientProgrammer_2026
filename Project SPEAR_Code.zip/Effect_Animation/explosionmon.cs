using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class explosionmon : MonoBehaviour
{
    private PlayerHealthPlusUI takedamage;
    public AudioSource ExplosionSound;
    public GameObject ExplosionPrefab;
    private GameObject Parent;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && gameObject.GetComponent<EnemyType>().monType == MonType.Enemy2)
        {
            takedamage.TakeDamage(2);
            takedamage.StartInvincibility();

            gameObject.GetComponent<BoxCollider2D>().enabled = false;
            gameObject.GetComponent<SpriteRenderer>().enabled = false;

            ExplosionSound.Play();

            GameObject explosion = Instantiate(ExplosionPrefab, transform.position, Quaternion.identity, Parent.transform.parent);

            Animator animator = explosion.GetComponent<Animator>();
            animator.SetBool("isExplosion", true);

            StartCoroutine(CamShake.Instance.Shake(0.08f, 0.8f));

            StartCoroutine(DestroyExplosion(explosion));
        }
    }

    IEnumerator DestroyExplosion(GameObject explosion)
    {
        yield return new WaitForSeconds(0.3f);

        Destroy(explosion);
        Destroy(gameObject);
    }
}
