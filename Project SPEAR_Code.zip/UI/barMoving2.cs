using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class barMoving2 : MonoBehaviour
{
    public Transform iconTransform;
    public int remainingMonsterCount;
    private float iconstartposition;
    private WaveManager waveManager;
    private float moveSpeed = 8f;

    public GameObject bossbar;
    public GameObject flag1;
    public GameObject flag2;
    public GameObject flag3;
    public GameObject flag4;
    public Animator barIconAni;
    public GameObject waveSet;
    public bool bosstime;
    public GameObject warnigTxt;

    private float w1count; 
    private float w2count; 
    private float w3count; 
    private float w4count; 
    private float w5count; 
    public int totalMonsterCount;
    private float w1move;
    private float w2move;
    private float w3move;
    private float w4move;
    private float w5move;
    private float w1long;
    private float w2long;
    private float w3long;
    private float w4long;

    private bool flag1Activated;
    private bool flag2Activated;
    private bool flag3Activated;
    private bool flag4Activated;
    private bool checkDone;
    public bool alreadySet;

    public bool stage1BGMChange;
    public bool bossBGMChange;
    public bool BGMChange;

    private void Start()
    {
        waveManager = FindObjectOfType<WaveManager>();
        iconstartposition = iconTransform.localPosition.x;
        flag1.SetActive(false);
        flag2.SetActive(false);
        flag3.SetActive(false);
        flag4.SetActive(false);
        barIconAni = GetComponent<Animator>();
    }

    private void Update()
    {
        if (waveManager == null) return;
        remainingMonsterCount = waveManager.GetMonsterCount();

        if (waveManager.Wave0AllMonster != 0 && !checkDone)
        {
            w1count = waveManager.Wave0AllMonster;
            w2count = waveManager.Wave1AllMonster;
            w3count = waveManager.Wave2AllMonster;
            w4count = waveManager.WaveNamedAllMonster;
            w5count = waveManager.Wave3AllMonster;
            w1move = 100f / w1count;
            w2move = 100f / w2count;
            w3move = 100f / w3count;
            w4move = 100f / w4count;
            w5move = 100f / w5count;
            w1long = w1move * w1count;
            w2long = w2move * w2count;
            w3long = w3move * w3count;
            w4long = w4move * w4count;
            totalMonsterCount = waveManager.GetMonsterCount();
            checkDone = true;
        }

        if (iconTransform.localPosition.x <= -150f)
        {

            if (iconTransform.localPosition.x < iconstartposition + (w1move * (totalMonsterCount - remainingMonsterCount)))
            {
                barIconAni.SetBool("moving", true);

                Vector3 newPosition = iconTransform.localPosition;
                newPosition.x += w1move * moveSpeed * Time.deltaTime;
                iconTransform.localPosition = newPosition;
            }
            else
            {
                barIconAni.SetBool("moving", false);
            }
        }

        else if (iconTransform.localPosition.x <= -50f)
        {
            if (iconTransform.localPosition.x < iconstartposition + w1long + (w2move * (totalMonsterCount - w1count - remainingMonsterCount)))
            {
                barIconAni.SetBool("moving", true);

                Vector3 newPosition = iconTransform.localPosition;
                newPosition.x += w1move * moveSpeed * Time.deltaTime;
                iconTransform.localPosition = newPosition;
            }
            else
            {
                barIconAni.SetBool("moving", false);
            }
        }

        else if (iconTransform.localPosition.x <= 50f)
        {
            if (iconTransform.localPosition.x < iconstartposition + (w1long + w2long) + (w3move * (totalMonsterCount - (w1count + w2count) - remainingMonsterCount)))
            {
                barIconAni.SetBool("moving", true);

                Vector3 newPosition = iconTransform.localPosition;
                newPosition.x += w1move * moveSpeed * Time.deltaTime;
                iconTransform.localPosition = newPosition;
            }
            else
            {
                barIconAni.SetBool("moving", false);
            }
        }

        else if (iconTransform.localPosition.x <= 150f)
        {
            if (iconTransform.localPosition.x < iconstartposition + (w1long + w2long + w3long) + (w4move * (totalMonsterCount - (w1count + w2count + w3count) - remainingMonsterCount)))
            {
                barIconAni.SetBool("moving", true);

                Vector3 newPosition = iconTransform.localPosition;
                newPosition.x += w1move * moveSpeed * Time.deltaTime;
                iconTransform.localPosition = newPosition;
            }
            else
            {
                barIconAni.SetBool("moving", false);
            }
        }

        else if (iconTransform.localPosition.x <= 250f)
        {
            if (iconTransform.localPosition.x < iconstartposition + (w1long + w2long + w3long + w4long) + (w5move * (totalMonsterCount - (w1count + w2count + w3count + w4count) - remainingMonsterCount)))
            {
                barIconAni.SetBool("moving", true);

                Vector3 newPosition = iconTransform.localPosition;
                newPosition.x += w1move * moveSpeed * Time.deltaTime;
                iconTransform.localPosition = newPosition;
            }
            else
            {
                barIconAni.SetBool("moving", false);
            }
        }

        if (remainingMonsterCount == 1)
        {
            bosstime = true;
            if (alreadySet)
                return;
            StartCoroutine(Set());
        }

        if (remainingMonsterCount <= totalMonsterCount - w1count && !flag1Activated && checkDone)
        {
            flag1.SetActive(true);
            flag1Activated = true;
        }

        if (remainingMonsterCount <= totalMonsterCount - w1count - w2count && !flag2Activated && checkDone)
        {
            flag2.SetActive(true);
            flag2Activated = true;
        }

        if (remainingMonsterCount <= totalMonsterCount - w1count - w2count - w3count && !flag3Activated && checkDone)
        {
            flag3.SetActive(true);
            flag3Activated = true;
        }

        if (remainingMonsterCount <= totalMonsterCount - w1count - w2count - w3count - w4count && !flag4Activated && checkDone)
        {
            flag4.SetActive(true);
            flag4Activated = true;
        }
    }

    IEnumerator Set()
    {
        alreadySet = true;
        gameObject.GetComponent<Image>().enabled = false;
        waveSet.SetActive(false);
        yield return new WaitForSeconds(2f);
        warnigTxt.SetActive(true);
        yield return new WaitForSeconds(3.6f);
        warnigTxt.SetActive(false);
        bossbar.SetActive(true);
        gameObject.SetActive(false);
    }
}
