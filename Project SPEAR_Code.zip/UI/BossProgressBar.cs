using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class BossProgressBar : MonoBehaviour
{
    public Image mask;

    private float targetFillAmount; 
    public float currentFillAmount; 

    public bool changingDone;

    public Color colorA;
    public Color colorB;
    private float colorChangeInterval = 0.05f;
    private bool isChangingColor;

    private BossManager bossManager;

    void Start()
    {
        currentFillAmount = mask.fillAmount = 1f;
        bossManager = FindObjectOfType<BossManager>();
    }

    IEnumerator ChangeColor()
    {
        isChangingColor = true;
        for (int i = 0; i < 3; i++)
        {
            mask.color = colorA;
            yield return new WaitForSeconds(colorChangeInterval);
            mask.color = colorB;
            yield return new WaitForSeconds(colorChangeInterval);
        }
        mask.color = colorA;
        isChangingColor = false;
    }

    void Update()
    {
        if ((bossManager.BossHp!=0 || bossManager != null) && !bossManager.comboCut )
        {
            int bosscurrentHP = bossManager.BossHp;
            targetFillAmount = (float)bosscurrentHP / bossManager.BossMaxHp;
            if (currentFillAmount != targetFillAmount)
            {
                float decreaseAmount = 1f / bossManager.BossMaxHp * Time.deltaTime * 20f;
                currentFillAmount = Mathf.Max(targetFillAmount, currentFillAmount - decreaseAmount); // �ּҰ��� targetFillAmount
                mask.fillAmount = currentFillAmount;
                StartCoroutine(ChangeColor());

                changingDone = true;
            }
            if (currentFillAmount == targetFillAmount)
            {
                mask.color = colorA;
            }
        }

        if (bossManager.BossHp == 0 || bossManager == null)
        {
            targetFillAmount = 0;
            if (currentFillAmount != targetFillAmount)
            {
                float decreaseAmount = 1f / bossManager.BossMaxHp * Time.deltaTime * 20f;
                currentFillAmount = Mathf.Max(targetFillAmount, currentFillAmount - decreaseAmount); // �ּҰ��� targetFillAmount
                mask.fillAmount = currentFillAmount;
            }
        }
    }
}

