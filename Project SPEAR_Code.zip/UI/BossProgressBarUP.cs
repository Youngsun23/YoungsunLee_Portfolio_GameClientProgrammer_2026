using UnityEngine;
using UnityEngine.UI;

public class BossProgressBarUP : MonoBehaviour
{
    public Image maskUP;
    private float targetFillAmount2; 
    private float currentFillAmount2;

    private BossProgressBar bossbar;
    private BossManager bossManager;

    void Start()
    {
        currentFillAmount2 = maskUP.fillAmount = 1f;
        bossbar = FindObjectOfType<BossProgressBar>();
        bossManager = FindObjectOfType<BossManager>();
    }

    void Update()
    {
        if ((bossManager.BossHp != 0 || bossManager != null) && bossManager.comboCut && bossbar.changingDone)
        {
            targetFillAmount2 = bossbar.currentFillAmount;
            if (currentFillAmount2 != targetFillAmount2)
            {
                float decreaseAmount = 1f / bossManager.BossMaxHp * Time.deltaTime * 20f; ; // 1/40 ��ŭ �����ϴ� �ð� ����
                currentFillAmount2 = Mathf.Max(targetFillAmount2, currentFillAmount2 - decreaseAmount); // �ּҰ��� targetFillAmount
                maskUP.fillAmount = currentFillAmount2;
            }
        }

        if (bossManager.BossHp == 0 || bossManager == null)
        {
            targetFillAmount2 = 0;
            if (currentFillAmount2 != targetFillAmount2)
            {
                float decreaseAmount = 1f / bossManager.BossMaxHp * Time.deltaTime * 20f;
                currentFillAmount2 = Mathf.Max(targetFillAmount2, currentFillAmount2 - decreaseAmount); // �ּҰ��� targetFillAmount
                maskUP.fillAmount = currentFillAmount2;
            }
        }

    }
}
