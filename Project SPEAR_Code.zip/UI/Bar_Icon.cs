using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Bar_Icon : MonoBehaviour
{
    public GameObject barIcon;
    public GameObject bossIcon;
    public GameObject start_obj;
    public GameObject parent_BarIcon;
    public GameObject parent_Goal;
    public GameObject parent_WaveBar;
    public GameObject parent_Flag;
    public GameObject prefeb_Goal;
    public GameObject prefeb_WaveBar;
    public GameObject prefeb_Flag;
    public GameObject waveSet;
    public GameObject warnigTxt;
    public GameObject bossbar;
    public List<GameObject> Flag;
    float distance;
    public WaveManager_new waveManager;
    public List<GameObject> goal_obj;
    public GameObject baricon;
    public bool noMoreCombo;

    public int cur_flag;
    Vector2 targetPos;
    Vector2 barPos;

    public bool alreadySet;

    void Start()
    {
        for (int i = 0; i + 1 < waveManager.wave_Round.Length; i++)
        {
            if (i + 2 != waveManager.wave_Round.Length)
            {
                goal_obj.Add(Instantiate(prefeb_Goal, parent_Goal.transform));
                Flag.Add(Instantiate(prefeb_Flag, parent_Flag.transform));
            }
            else
            {
                bossIcon.transform.SetAsLastSibling();
                Vector2 anchoredPosition = barIcon.GetComponent<RectTransform>().anchoredPosition;
                barIcon.GetComponent<RectTransform>().SetParent(parent_BarIcon.GetComponent<RectTransform>());
                barIcon.GetComponent<RectTransform>().anchoredPosition = new Vector2(anchoredPosition.x - (61f + 50.61f * (i + 1)), anchoredPosition.y);
            }
            Instantiate(prefeb_WaveBar, parent_WaveBar.transform);
        }
        for (int i = 0; i < Flag.Count; ++i)
        {
            Flag[i].GetComponent<Image>().enabled = false;
        }
        distance = 0f;
        targetPos = barIcon.GetComponent<RectTransform>().anchoredPosition;
        barPos = barIcon.GetComponent<RectTransform>().anchoredPosition;
        cur_flag = waveManager.cur_WaveRound;
    }

    public void DistanceMove()
    {
        if (cur_flag < goal_obj.Count)
        {
            distance = Vector2.Distance(goal_obj[cur_flag].GetComponent<RectTransform>().anchoredPosition, barPos);
            distance = distance / (waveManager.CurWaveCount(cur_flag));
        }
        else
        {
            distance = Vector2.Distance(bossIcon.GetComponent<RectTransform>().anchoredPosition, barPos);
            distance = distance / (waveManager.CurWaveCount(cur_flag));
        }
        targetPos.x = barIcon.GetComponent<RectTransform>().anchoredPosition.x + distance;
        barIcon.GetComponent<RectTransform>().anchoredPosition = targetPos;

    }
    public void FlagOn()
    {
        if (cur_flag != waveManager.cur_WaveRound)
        {
            Flag[cur_flag].GetComponent<Image>().enabled = true;
            cur_flag = waveManager.cur_WaveRound;
            barPos = barIcon.GetComponent<RectTransform>().anchoredPosition;
        }
    }

    private void Update()
    {
        if (waveManager.bossActivated)
        {
            StartCoroutine(Set());
        }
    }
    IEnumerator Set()
    {
        alreadySet = true;
        baricon.GetComponent<Image>().enabled = false;
        waveSet.SetActive(false);
        yield return new WaitForSeconds(2f);
        warnigTxt.SetActive(true);
        yield return new WaitForSeconds(3.6f);
        noMoreCombo = true;
        warnigTxt.SetActive(false);
        bossbar.SetActive(true);
        gameObject.SetActive(false);
    }
}
